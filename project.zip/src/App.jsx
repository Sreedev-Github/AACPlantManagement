import React, { useState, useEffect, useRef } from 'react';
import { initializeApp } from 'firebase/app';
import { 
  getFirestore, collection, addDoc, onSnapshot, 
  doc, updateDoc, deleteDoc, query, orderBy, serverTimestamp, setDoc
} from 'firebase/firestore';
import { 
  getAuth, signInAnonymously, onAuthStateChanged, 
  signInWithCustomToken
} from 'firebase/auth';
import { 
  Package, Truck, FileText, CheckCircle, 
  AlertCircle, LogOut, Plus, DollarSign, 
  Briefcase, ArrowRight, RefreshCw, Upload,
  ChevronLeft, ChevronRight, Calendar, FlaskConical,
  LayoutGrid, Clock, ShieldCheck, AlertTriangle,
  Filter, X, Search, Eye, Scale, Users, Droplet,
  BarChart3, PieChart, Download, Fuel, ClipboardList, Save, GripVertical,
  Pencil, Trash2, ScrollText, History, FileUp, FileSpreadsheet, Factory, Layers, Boxes
} from 'lucide-react';

const firebaseConfig = {
  apiKey: "AIzaSyBvcesaWjLf9RBvEzChTci3bRMih7U3A9s",
  authDomain: "aac-plant.firebaseapp.com",
  projectId: "aac-plant",
  storageBucket: "aac-plant.firebasestorage.app",
  messagingSenderId: "202738671266",
  appId: "1:202738671266:web:4c855d8135bf2167d5c1fb"
};

// --- Firebase Configuration ---
const firebaseConfiged = firebaseConfig;
const app = initializeApp(firebaseConfiged);
const auth = getAuth(app);
const db = getFirestore(app);
const appId = typeof __app_id !== 'undefined' ? __app_id : 'aac-plant-default';

// --- Constants ---
const SIZES = [
  "600x200x75",
  "600x200x100",
  "600x200x125",
  "600x200x150",
  "600x200x200",
  "600x200x225",
  "600x200x250",
  "600x200x300"
];

const LOADING_STATUSES = [
  'Awaiting Truck',
  'Truck at Site',
  'Loading',
  'Loading Complete'
];

// Rate Configuration
const RATE_CARD = {
  loading: { 4: 400, 6: 800, 10: 1000, 12: 1400, 14: 1600, 16: 1800, 18: 2000 },
  unloading: { 4: 600, 6: 1000, 10: 1800, 12: 2200, 14: 2500 } 
};

const GS_SURCHARGE = 500;

// --- Production Constants ---

const RAW_MATERIALS_LIST = [
    { desc: "FLYASH", unit: "Ton" },
    { desc: "CEMENT", unit: "Ton" },
    { desc: "LIME POWDER", unit: "Ton" },
    { desc: "GYPSUM (POP)", unit: "Ton" },
    { desc: "RICE HUSK", unit: "Ton" },
    { desc: "ALUM. POWDER", unit: "KG" },
    { desc: "SOLUBLE OIL", unit: "Ltr" },
    { desc: "MOULD OIL", unit: "Ltr" },
    { desc: "HARDENER", unit: "KG" },
    { desc: "CHARCOAL", unit: "KG" },
    { desc: "SALT", unit: "KG" },
    { desc: "COAL", unit: "Ton" },
];

const FINISHED_STOCK_SIZES = [
    "600X250X200", "600X250X125", "600X200X250", "600X200X230", "600X200X225", "600X200X200", 
    "600X200X150", "600X200X150(P)", "600X200X125", "600X200X100", "600X200X75", "600X200X350", 
    "600X200X250(B)", "600X200X225 (B)", "600X200X200(B)", "600X200X150(B)", "600X200X100 (B)", 
    "600x200x125 (B)", "600x200x200 (HD)", "600X200X100 (HD)", "600X250X250"
];

// --- Helpers ---

const getTodayString = () => {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
};

const getPreviousDateString = (dateString) => {
  const parts = dateString.split('-');
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12, 0, 0));
  date.setDate(date.getDate() - 1);
  return date.toISOString().split('T')[0];
};

const formatDateTimeDisplay = (timestamp) => {
  if (!timestamp) return '';
  const date = new Date(timestamp.seconds * 1000);
  return date.toLocaleString('en-US', { 
    month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' 
  });
};

const formatDateDisplay = (dateString) => {
  if (!dateString) return '';
  const parts = dateString.split('-');
  const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12, 0, 0));
  return date.toLocaleDateString('en-US', { weekday: 'short', day: 'numeric', month: 'long', year: 'numeric' });
};

// ** NEW HELPER FUNCTION FOR LOCAL DATE CONSISTENCY **
const getLocalOrderDateString = (timestamp) => {
    if (!timestamp || !timestamp.seconds) return getTodayString();
    const d = new Date(timestamp.seconds * 1000);
    const year = d.getFullYear();
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const day = String(d.getDate()).padStart(2, '0');
    return `${year}-${month}-${day}`;
};

const safeNum = (val) => {
  const parsed = parseFloat(val);
  return isNaN(parsed) ? 0 : parsed;
};

const safeInt = (val) => {
  const parsed = parseInt(val);
  return isNaN(parsed) ? 0 : parsed;
};

const convertTimeTo24h = (time12h) => {
    if (!time12h) return '';
    const [time, modifier] = time12h.split(' ');
    let [hours, minutes] = time.split(':');
    if (hours === '12') hours = '00';
    if (modifier === 'PM') hours = parseInt(hours, 10) + 12;
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}`;
};

const calculatePiecesLoaded = (cbm, size) => {
    if (!cbm || !size) return 0;
    const blockCBM = 0.024; 
    return Math.round(cbm / blockCBM);
};

const calculateColumnTotal = (data, field) => {
    if (!data) return 0;
    return data.reduce((acc, item) => acc + safeNum(item[field]), 0).toFixed(2);
  };

// --- Sub-Components ---

const StatusBadge = ({ status }) => {
  let label = status.toUpperCase();
  let style = 'bg-gray-100 text-gray-800 border-gray-200';
  if (status === 'Awaiting Truck') style = 'bg-yellow-50 text-yellow-700 border-yellow-200';
  else if (status === 'Truck at Site') style = 'bg-orange-50 text-orange-700 border-orange-200';
  else if (status === 'Loading') style = 'bg-blue-50 text-blue-700 border-blue-200 animate-pulse';
  else if (status === 'Loading Complete') { label = "LOADING COMPLETE - Awaiting Bill"; style = 'bg-red-50 text-red-700 border-red-200 font-bold'; }
  else if (status === 'Invoiced') { label = "LOADING COMPLETE - Checking Bill"; style = 'bg-indigo-50 text-indigo-700 border-indigo-200'; }
  else if (status === 'Approved') { label = "LOADING COMPLETE - Invoice Received"; style = 'bg-emerald-100 text-emerald-800 border-emerald-200 font-bold'; }
  else if (status === 'Dispatched') { label = "DISPATCHED"; style = 'bg-slate-800 text-white border-slate-800'; }
  return <span className={`px-3 py-1 rounded-full text-[10px] font-bold border tracking-wide text-center ${style}`}>{label}</span>;
};

const Card = ({ children, className = "", onClick }) => (
  <div onClick={onClick} className={`bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden ${className} ${onClick ? 'cursor-pointer hover:shadow-md transition-shadow' : ''}`}>
    {children}
  </div>
);

const StatCard = ({ label, value, icon: Icon, colorClass, onClick }) => (
  <Card className={`p-4 flex items-center space-x-4 border-l-4 ${onClick ? 'cursor-pointer hover:bg-slate-50' : ''}`} style={{ borderLeftColor: 'currentColor' }} onClick={onClick}>
    <div className={`p-3 rounded-lg ${colorClass} bg-opacity-20`}><Icon className={`w-6 h-6 ${colorClass.replace('bg-', 'text-')}`} /></div>
    <div><p className="text-xs font-bold text-slate-400 uppercase">{label}</p><p className="text-2xl font-bold text-slate-800">{value}</p></div>
  </Card>
);

const InputGroup = ({ label, children }) => (
  <div className="space-y-1"><label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">{label}</label>{children}</div>
);

const EditableCell = ({ value, onUpdate, type = "text", className = "", inputMode = "text", tableId, rowIndex, colIndex }) => {
  const [isEditing, setIsEditing] = useState(false);
  const [localValue, setLocalValue] = useState(value || '');
  const inputRef = useRef(null);
  const cellRef = useRef(null);

  useEffect(() => { setLocalValue(value || ''); }, [value]);

  useEffect(() => {
    if (isEditing && inputRef.current) {
      inputRef.current.focus();
    }
  }, [isEditing]);

  const handleChange = (e) => {
      const newValue = e.target.value;
      if (inputMode === 'decimal') {
          if (newValue === '' || /^\d*\.?\d*$/.test(newValue)) {
              setLocalValue(newValue);
          }
      } else {
          setLocalValue(newValue);
      }
  };

  const finishEditing = () => {
      setIsEditing(false);
      if (localValue !== value) {
          onUpdate(localValue);
      }
  };

  const handleKeyDownInput = (e) => {
    if (e.key === 'Enter') {
        finishEditing();
        navigateGrid('ArrowDown');
    }
  };

  const navigateGrid = (direction) => {
     if (!tableId) return;
     let nextRow = rowIndex;
     let nextCol = colIndex;
     if (direction === 'ArrowUp') nextRow--;
     if (direction === 'ArrowDown') nextRow++;
     if (direction === 'ArrowLeft') nextCol--;
     if (direction === 'ArrowRight') nextCol++;
     const nextCell = document.querySelector(`div[data-cell="${tableId}-${nextRow}-${nextCol}"]`);
     if (nextCell) {
         nextCell.focus();
         nextCell.click();
     }
  };

  const handleKeyDownDiv = (e) => {
      if (e.key === 'Enter') {
          e.preventDefault();
          setIsEditing(true);
      } else if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
          e.preventDefault();
          navigateGrid(e.key);
      }
  };

  if (isEditing) {
      return (
          <input 
            ref={inputRef}
            type={type} 
            inputMode={inputMode} 
            className={`w-full h-full bg-white border border-blue-500 outline-none font-bold text-sm text-slate-800 px-2 py-1 rounded shadow-sm ${className}`} 
            value={localValue} 
            onChange={handleChange} 
            onBlur={finishEditing} 
            onKeyDown={handleKeyDownInput} 
        />
      );
  }

  return (
      <div 
        ref={cellRef}
        tabIndex={0}
        data-cell={`${tableId}-${rowIndex}-${colIndex}`}
        onClick={() => setIsEditing(true)}
        onKeyDown={handleKeyDownDiv}
        className={`w-full h-full px-1 py-3 cursor-text hover:bg-blue-50 focus:bg-blue-100 focus:outline-none focus:ring-2 focus:ring-blue-300 rounded transition-colors font-bold text-sm text-slate-700 leading-relaxed ${className} flex items-center justify-end`}
      >
        {value || (value === 0 ? '0' : '')}
      </div>
  );
};

// --- Dispatch Modal & Preview ---
const DispatchSlipContent = ({ order }) => (
    <div className="p-8 bg-white border border-slate-300 rounded-lg shadow-xl w-full max-w-sm mx-auto text-sm font-mono">
        <h3 className="text-center text-lg font-bold mb-4 border-b pb-2">DISPATCH SLIP (SIMULATED)</h3>
        <p className="text-xs text-slate-500 mb-4">Order ID: {order.id}</p>
        <div className="space-y-2">
            <div className="grid grid-cols-2"><span className="text-slate-600">Date:</span><span className="font-bold text-slate-800">{order.orderDate}</span></div>
            <div className="grid grid-cols-2"><span className="text-slate-600">Consignee:</span><span className="font-bold text-slate-800">{order.consignee || order.client}</span></div>
            <div className="grid grid-cols-2"><span className="text-slate-600">Address:</span><span className="text-slate-800 break-words text-xs">{order.address || order.location}</span></div>
            <div className="grid grid-cols-2"><span className="text-slate-600">Vehicle No:</span><span className="font-bold text-slate-800">{order.vehicle}</span></div>
            <div className="grid grid-cols-2"><span className="text-slate-600">Driver:</span><span className="text-slate-800">{order.driverName || 'N/A'}</span></div>
            <div className="grid grid-cols-2"><span className="text-slate-600">Pieces Loaded:</span><span className="font-bold text-slate-800">{order.piecesLoaded || 'N/A'}</span></div>
            <div className="grid grid-cols-2"><span className="text-slate-600">CBM:</span><span className="font-bold text-slate-800">{order.cbm}</span></div>
             <div className="grid grid-cols-2"><span className="text-slate-600">BJM Bags:</span><span className="font-bold text-slate-800">{order.bjm || 'N/A'}</span></div>
        </div>
        <div className="mt-4 pt-3 border-t border-slate-200"><h4 className="text-xs font-bold text-slate-600 mb-2">TIMING</h4><div className="grid grid-cols-2 text-xs"><span className="text-slate-500">Load Start:</span><span className="font-semibold text-slate-700">{order.loadStartTime || '-'}</span></div><div className="grid grid-cols-2 text-xs"><span className="text-slate-500">Load Finish:</span><span className="font-semibold text-slate-700">{order.loadFinishTime || '-'}</span></div></div>
        <div className="mt-4 pt-3 border-t border-slate-200"><h4 className="text-xs font-bold text-slate-600 mb-2">WEIGHT DETAILS (Tons)</h4><div className="grid grid-cols-3 text-xs"><span className="text-slate-500 font-bold">Gr. Wt.</span><span className="text-slate-500 font-bold">Tr. Wt.</span><span className="text-slate-500 font-bold">Nr. Wt.</span></div><div className="grid grid-cols-3 font-bold text-sm"><span>{order.grossWeight || '-'}</span><span>{order.tareWeight || '-'}</span><span className="text-green-700">{order.netWt || '-'}</span></div></div>
        <div className="mt-4 pt-3 border-t border-slate-200"><div className="grid grid-cols-2 text-xs"><span className="text-slate-600">Contact Person:</span><span className="font-bold text-slate-800">{order.contactPerson || '-'}</span></div><div className="grid grid-cols-2 text-xs"><span className="text-slate-600">Driver Contact:</span><span className="font-bold text-slate-800">{order.driverContact || '-'}</span></div></div>
    </div>
);

const ImportModal = ({ onClose, onImport }) => {
  const [file, setFile] = useState(null);
  const [status, setStatus] = useState('idle'); 
  const handleFileChange = (e) => { if (e.target.files) setFile(e.target.files[0]); };
  const processCSV = async () => {
    if (!file) return; setStatus('parsing');
    const reader = new FileReader();
    reader.onload = async (e) => {
      const text = e.target.result; const rows = text.split('\n'); const data = [];
      for (let i = 1; i < rows.length; i++) {
        const row = rows[i].split(',').map(cell => cell.trim());
        if (row.length < 5) continue; 
        data.push({ orderDate: row[0] || getTodayString(), client: row[1] || 'Unknown', location: row[2] || '', vehicle: row[3] || '', transporter: row[4] || '', size: row[5] || SIZES[0], cbm: parseFloat(row[6]) || 0, rate: parseFloat(row[7]) || 0, status: 'Dispatched', createdAt: serverTimestamp(), truckType: null, gsChecked: false, loadingRate: 0, unloadingRate: 0 });
      }
      onImport(data); setStatus('success');
    };
    reader.readAsText(file);
  };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-xl shadow-2xl max-w-md w-full p-6">
        <div className="flex justify-between items-center mb-4"><h3 className="font-bold text-lg text-slate-800 flex items-center gap-2"><FileUp className="w-5 h-5"/> Import Data</h3><button onClick={onClose}><X className="w-5 h-5 text-slate-400"/></button></div>
        <div className="bg-blue-50 p-3 rounded-lg border border-blue-100 text-xs text-blue-700 mb-4"><strong>Instructions:</strong> Upload a CSV file with columns: <br/> Date (YYYY-MM-DD), Client, Location, Vehicle, Transporter, Size, CBM, Rate</div>
        <input type="file" accept=".csv" onChange={handleFileChange} className="block w-full text-sm text-slate-500 file:mr-4 file:py-2 file:px-4 file:rounded-full file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-blue-700 hover:file:bg-blue-100 mb-4"/>
        <div className="flex justify-end gap-2"><button onClick={onClose} className="px-4 py-2 text-slate-500 font-bold text-sm">Cancel</button><button onClick={processCSV} disabled={!file || status === 'parsing'} className="px-4 py-2 bg-blue-600 text-white rounded-lg font-bold text-sm hover:bg-blue-700 disabled:opacity-50">{status === 'parsing' ? 'Processing...' : 'Start Import'}</button></div>
      </div>
    </div>
  );
};

const ConfirmModal = ({ title, message, onConfirm, onCancel }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4 backdrop-blur-sm animate-in fade-in duration-200">
    <div className="bg-white rounded-xl shadow-2xl max-w-sm w-full p-6">
      <div className="flex items-center gap-3 mb-4 text-red-600"><AlertTriangle className="w-6 h-6" /><h3 className="font-bold text-lg">{title}</h3></div><p className="text-slate-600 mb-6">{message}</p>
      <div className="flex justify-end gap-3"><button onClick={onCancel} className="px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-100 rounded-lg">Cancel</button><button onClick={onConfirm} className="px-4 py-2 text-sm font-bold text-white bg-red-600 hover:bg-red-700 rounded-lg shadow-sm">Delete</button></div>
    </div>
  </div>
);

const DocPreviewModal = ({ fileType, fileName, onClose, onApprove, canApprove, orderData }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4 backdrop-blur-sm animate-in fade-in duration-200">
    <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden flex flex-col max-h-[90vh]">
      <div className="p-4 border-b border-slate-100 flex justify-between items-center"><h3 className="font-bold text-slate-800 flex items-center gap-2">{fileType === 'invoice' ? <FileText className="text-indigo-600"/> : <CheckCircle className="text-purple-600"/>} Previewing: {fileName}</h3><button onClick={onClose}><X className="w-5 h-5 text-slate-400 hover:text-slate-600"/></button></div>
      <div className="flex-1 bg-slate-100 p-8 flex flex-col items-center justify-start min-h-[300px] overflow-y-auto">
        {fileType === 'slip' && orderData ? (<DispatchSlipContent order={orderData} />) : (<div className="w-24 h-32 bg-white shadow-md border border-slate-200 mb-4 flex items-center justify-center"><span className="text-xs text-slate-300 font-bold">PDF / IMG</span></div>)}
        <p className="text-slate-500 text-sm mt-4">Document Preview Loaded</p><p className="text-xs text-slate-400">{fileName}</p>
      </div>
      <div className="p-4 border-t border-slate-100 bg-slate-50 flex justify-end gap-3"><button onClick={onClose} className="px-4 py-2 text-sm font-bold text-slate-600 hover:bg-slate-200 rounded-lg transition-colors">Close Preview</button>{canApprove && (<button onClick={onApprove} className="px-4 py-2 text-sm font-bold text-white bg-green-600 hover:bg-green-700 rounded-lg transition-colors shadow-sm flex items-center gap-2"><CheckCircle className="w-4 h-4" /> Approve Document</button>)}</div>
    </div>
  </div>
);

const DispatchModal = ({ order, onClose, onSubmit, logs }) => {
  const isABC = order.transporter && order.transporter.toUpperCase() === 'ABC';
  const loadingStartLog = logs.find(log => log.details.includes(`Updated Order ${order.id} to Loading`));
  const loadingFinishLog = logs.find(log => log.details.includes(`Updated Order ${order.id} to Loading Complete`));

  const defaultStartTime = loadingStartLog?.timestamp ? new Date(loadingStartLog.timestamp.seconds * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }) : new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  const defaultFinishTime = loadingFinishLog?.timestamp ? new Date(loadingFinishLog.timestamp.seconds * 1000).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false }) : new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', hour12: false });
  const defaultPieces = order.piecesLoaded || calculatePiecesLoaded(order.cbm, order.size);

  const [dForm, setDForm] = useState({ 
    consignee: order.consignee || order.client || '', address: order.address || order.location || '', contactPerson: order.contactPerson || '', size: order.size || SIZES[3], cbm: order.cbm || '', piecesLoaded: defaultPieces, bjm: order.bjm || '', bjmRate: order.bjmRate || '', 
    vehicle: order.vehicle || '', truckType: order.truckType || '', transporter: order.transporter || '', driverName: order.driverName || '', driverContact: order.driverContact || '',
    loadStartTime: convertTimeTo24h(order.loadStartTime) || defaultStartTime, loadFinishTime: convertTimeTo24h(order.loadFinishTime) || defaultFinishTime, loadingBy: order.loadingBy || '', unloadingBy: order.unloadingBy || '', 
    grossWeight: order.grossWeight || '', tareWeight: order.tareWeight || '', tripKm: order.tripKm || '', hsd: order.hsd || '', 
  });

  const calculatedNetWt = (parseFloat(dForm.grossWeight) || 0) - (parseFloat(dForm.tareWeight) || 0);
  const getClassName = (fieldValue) => `w-full p-2.5 border border-slate-300 rounded-lg outline-none focus:ring-2 focus:ring-purple-500 ${fieldValue ? 'bg-slate-100 border-slate-400 font-medium' : ''}`;

  const handleFormSubmit = (e) => {
    e.preventDefault();
    const timeTo12h = (time24h) => {
        if (!time24h) return '';
        const [h, m] = time24h.split(':');
        const hours = parseInt(h, 10);
        const suffix = hours >= 12 ? 'PM' : 'AM';
        const displayHours = ((hours + 11) % 12) + 1; 
        return `${displayHours}:${m} ${suffix}`;
    };
    const finalData = {
        consignee: dForm.consignee, address: dForm.address, contactPerson: dForm.contactPerson, size: dForm.size, cbm: Number(dForm.cbm), piecesLoaded: Number(dForm.piecesLoaded), bjm: Number(dForm.bjm), bjmRate: Number(dForm.bjmRate),
        vehicle: dForm.vehicle, truckType: Number(dForm.truckType), transporter: dForm.transporter, driverName: dForm.driverName, driverContact: dForm.driverContact,
        loadStartTime: timeTo12h(dForm.loadStartTime), loadFinishTime: timeTo12h(dForm.loadFinishTime), loadingBy: dForm.loadingBy, unloadingBy: isABC ? dForm.unloadingBy : null, 
        grossWeight: Number(dForm.grossWeight).toFixed(3), tareWeight: Number(dForm.tareWeight).toFixed(3), netWt: calculatedNetWt.toFixed(3),
        tripKm: isABC ? Number(dForm.tripKm) : null, hsd: isABC ? Number(dForm.hsd) : null,
    };
    onSubmit(order.id, finalData);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4 backdrop-blur-sm animate-in fade-in duration-200">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex justify-between items-center bg-purple-50"><h3 className="font-bold text-purple-900 flex items-center gap-2"><Truck className="w-5 h-5"/> Generate Dispatch Slip & Dispatch</h3><button onClick={onClose}><X className="w-5 h-5 text-purple-400 hover:text-purple-600"/></button></div>
        <form onSubmit={handleFormSubmit} className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          {isABC && (<div className="p-3 bg-purple-50 rounded-lg border border-purple-100 mb-4"><p className="text-xs text-purple-700 font-bold flex items-center"><AlertTriangle className="w-3 h-3 mr-1"/> Transporter is ABC: Full HSD/KM log required.</p></div>)}
            <h4 className="text-sm font-bold text-purple-700 border-b pb-1">SHIPMENT DETAILS</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <InputGroup label="Consignee (P)"><input required type="text" className={getClassName(dForm.consignee)} value={dForm.consignee} onChange={e => setDForm({...dForm, consignee: e.target.value})} placeholder={order.client} /></InputGroup>
            <InputGroup label="Address (P)"><input required type="text" className={getClassName(dForm.address)} value={dForm.address} onChange={e => setDForm({...dForm, address: e.target.value})} placeholder={order.location} /></InputGroup>
            <InputGroup label="Contact Person"><input type="text" className={getClassName(dForm.contactPerson)} value={dForm.contactPerson} onChange={e => setDForm({...dForm, contactPerson: e.target.value})} placeholder="e.g. 7008..." /></InputGroup>
            <InputGroup label="AAC Size (P)"><select className={getClassName(dForm.size)} value={dForm.size} onChange={e => setDForm({...dForm, size: e.target.value})}>{SIZES.map(s => <option key={s} value={s}>{s}</option>)}</select></InputGroup>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
             <InputGroup label="CBM (P)"><input required type="text" inputMode="decimal" className={getClassName(dForm.cbm)} value={dForm.cbm} onChange={e => setDForm({...dForm, cbm: e.target.value})} /></InputGroup>
             <InputGroup label="Pieces Loaded"><input required type="text" inputMode="decimal" className={getClassName(dForm.piecesLoaded)} value={dForm.piecesLoaded} onChange={e => setDForm({...dForm, piecesLoaded: e.target.value})} placeholder={defaultPieces} /></InputGroup>
             <InputGroup label="BJM Bags (P)"><input required type="text" inputMode="decimal" className={getClassName(dForm.bjm)} value={dForm.bjm} onChange={e => setDForm({...dForm, bjm: e.target.value})} placeholder={order.bjm} /></InputGroup>
             <InputGroup label="BJM Rate"><input required type="text" inputMode="decimal" className={getClassName(dForm.bjmRate)} value={dForm.bjmRate} onChange={e => setDForm({...dForm, bjmRate: e.target.value})} placeholder={order.bjmRate || '0'} /></InputGroup>
          </div>
            <h4 className="text-sm font-bold text-purple-700 border-b pb-1 pt-2">VEHICLE DETAILS</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
             <InputGroup label="Vehicle No (P)"><input required type="text" className={getClassName(dForm.vehicle)} value={dForm.vehicle} onChange={e => setDForm({...dForm, vehicle: e.target.value})} placeholder={order.vehicle} /></InputGroup>
             <InputGroup label="Truck Type"><div className="relative"><input required type="text" inputMode="decimal" className={getClassName(dForm.truckType)} value={dForm.truckType} onChange={e => setDForm({...dForm, truckType: e.target.value})} placeholder="e.g. 12" /><span className="absolute right-3 top-2.5 text-slate-400 font-bold text-sm">W</span></div></InputGroup>
             <InputGroup label="Transporter (P)"><input required type="text" className={getClassName(dForm.transporter)} value={dForm.transporter} onChange={e => setDForm({...dForm, transporter: e.target.value})} placeholder={order.transporter} /></InputGroup>
             <InputGroup label="Driver Name"><input required type="text" className={getClassName(dForm.driverName)} value={dForm.driverName} onChange={e => setDForm({...dForm, driverName: e.target.value})} placeholder="Driver" /></InputGroup>
          </div>
          <div className="max-w-md"><InputGroup label="Driver Contact"><input type="text" className={getClassName(dForm.driverContact)} value={dForm.driverContact} onChange={e => setDForm({...dForm, driverContact: e.target.value})} placeholder="e.g. 9348..." /></InputGroup></div>
            <h4 className="text-sm font-bold text-purple-700 border-b pb-1 pt-2">TIMING & PERSONNEL</h4>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <InputGroup label="Load Start Time"><input required type="time" className={getClassName(dForm.loadStartTime)} value={dForm.loadStartTime} onChange={e => setDForm({...dForm, loadStartTime: e.target.value})} /></InputGroup>
            <InputGroup label="Load Finish Time"><input required type="time" className={getClassName(dForm.loadFinishTime)} value={dForm.loadFinishTime} onChange={e => setDForm({...dForm, loadFinishTime: e.target.value})} /></InputGroup>
            <InputGroup label="Loading By"><input required type="text" className={getClassName(dForm.loadingBy)} value={dForm.loadingBy} onChange={e => setDForm({...dForm, loadingBy: e.target.value})} placeholder="Labor Name" /></InputGroup>
            {isABC && (<InputGroup label="Unloading By (ABC Only)"><input type="text" className={getClassName(dForm.unloadingBy)} value={dForm.unloadingBy} onChange={e => setDForm({...dForm, unloadingBy: e.target.value})} placeholder='Labor Name' /></InputGroup>)}
          </div>
            <h4 className="text-sm font-bold text-purple-700 border-b pb-1 pt-2">WEIGHTS (Tons)</h4>
          <div className="grid grid-cols-3 gap-4">
            <InputGroup label="Gross Weight (Gr. Wt.)"><input required type="text" inputMode="decimal" className={getClassName(dForm.grossWeight)} value={dForm.grossWeight} onChange={e => setDForm({...dForm, grossWeight: e.target.value})} placeholder="e.g. 28.510" /></InputGroup>
            <InputGroup label="Tare Weight (Tr. Wt.)"><input required type="text" inputMode="decimal" className={getClassName(dForm.tareWeight)} value={dForm.tareWeight} onChange={e => setDForm({...dForm, tareWeight: e.target.value})} placeholder="e.g. 9.260" /></InputGroup>
            <InputGroup label="Net Weight (Nr. Wt.)"><input readOnly type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-green-500 outline-none bg-green-50 text-green-700 font-bold" value={calculatedNetWt.toFixed(3)} /></InputGroup>
          </div>
            {isABC && (<div className="animate-in fade-in slide-in-from-top-2"><h4 className="text-sm font-bold text-purple-700 border-b pb-1 pt-2">TRIP LOG (ABC ONLY)</h4><div className="grid grid-cols-2 gap-4 max-w-lg"><InputGroup label="Trip KM"><input required type="text" inputMode="decimal" className={getClassName(dForm.tripKm)} value={dForm.tripKm} onChange={e => setDForm({...dForm, tripKm: e.target.value})} placeholder="0" /></InputGroup><InputGroup label="HSD (Litres)"><input required type="text" className={getClassName(dForm.hsd)} value={dForm.hsd} onChange={e => setDForm({...dForm, hsd: e.target.value})} placeholder="0.00" /></InputGroup></div></div>)}
          <button type="submit" className="w-full py-3 bg-purple-600 text-white font-bold rounded-lg hover:bg-purple-700 transition-colors shadow-md mt-4">Confirm Dispatch & Generate Slip</button>
        </form>
      </div>
    </div>
  );
};

// --- Main Application ---

export default function App() {
  const [user, setUser] = useState(null);
  const [role, setRole] = useState(null);
  const [loading, setLoading] = useState(true);
  const [authError, setAuthError] = useState(null);
  const [orders, setOrders] = useState([]);
  const [dieselEntries, setDieselEntries] = useState([]); 
  const [logs, setLogs] = useState([]); 
  const [rawStock, setRawStock] = useState({});
  const [finishedStock, setFinishedStock] = useState({});
  const [isHtml2CanvasReady, setIsHtml2CanvasReady] = useState(false); 
  
  const [view, setView] = useState('home');
  const [productionTab, setProductionTab] = useState('raw-material'); 
  const [appMsg, setAppMsg] = useState(null); 
  const [viewDate, setViewDate] = useState(getTodayString());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState('date');

  const [previewFile, setPreviewFile] = useState(null);
  const [dispatchModalOrderId, setDispatchModalOrderId] = useState(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState(null); 
  const [showImportModal, setShowImportModal] = useState(false);

  const [editingOrderId, setEditingOrderId] = useState(null); 

  const [formData, setFormData] = useState({
    client: '', location: '', vehicle: '', transporter: '', 
    size: SIZES[3], cbm: '', bjm: '', rate: '', bjmRate: ''
  });

  const [manualDieselForm, setManualDieselForm] = useState({
    date: getTodayString(), name: '', location: '', driver: '', hsd: ''
  });
  
  // Script Loading Effect
  useEffect(() => {
    const scriptId = 'html2canvas-script';
    if (window.html2canvas) {
      setIsHtml2CanvasReady(true);
      return;
    }

    if (!document.getElementById(scriptId)) {
        const script = document.createElement('script');
        script.src = "https://cdnjs.cloudflare.com/ajax/libs/html2canvas/1.4.1/html2canvas.min.js";
        script.id = scriptId;
        script.async = true;
        script.onload = () => {
            setIsHtml2CanvasReady(true);
            showToast("Report download tool ready!");
        };
        script.onerror = () => {
             console.error("Failed to load html2canvas");
             showToast("Error loading download tool.");
        };
        document.body.appendChild(script);
    }
    
    return () => {
    };
  }, []);


  useEffect(() => {
    let mounted = true;
    const initAuth = async () => {
      try {
        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
          await signInWithCustomToken(auth, __initial_auth_token);
        } else {
          await signInAnonymously(auth);
        }
      } catch (err) {
        if (mounted) { setAuthError(err.message); }
      } finally {
        if (mounted) { setLoading(false); } 
      }
    };

    initAuth();
    
    const unsubscribe = onAuthStateChanged(auth, (u) => {
      if (!mounted) return;
      setUser(u);
    });
    return () => { mounted = false; unsubscribe(); };
  }, []);


  useEffect(() => {
    if (!user) return;
    let unsubscribeOrders = () => {};
    let unsubscribeDiesel = () => {};
    let unsubscribeLogs = () => {};
    let unsubscribeRaw = () => {};
    let unsubscribeFinished = () => {};

    try {
      const qOrders = query(collection(db, 'artifacts', appId, 'public', 'data', 'orders'), orderBy('createdAt', 'desc'));
      unsubscribeOrders = onSnapshot(qOrders, (snapshot) => {
        const fetchedOrders = snapshot.docs.map(doc => {
          const data = doc.data();
          let orderDate = data.orderDate;
          if (!orderDate && data.createdAt) {
             // FIX APPLIED HERE: Use getLocalOrderDateString instead of UTC-based ISOString conversion
             // Recreating local helper inline to be safe inside effect closure
             if (data.createdAt && data.createdAt.seconds) {
                 const d = new Date(data.createdAt.seconds * 1000);
                 const year = d.getFullYear();
                 const month = String(d.getMonth() + 1).padStart(2, '0');
                 const day = String(d.getDate()).padStart(2, '0');
                 orderDate = `${year}-${month}-${day}`;
             } else {
                 orderDate = new Date().toISOString().split('T')[0];
             }
          }
          return { id: doc.id, ...data, orderDate };
        });
        setOrders(fetchedOrders);
      });

      const qDiesel = query(collection(db, 'artifacts', appId, 'public', 'data', 'diesel_entries'), orderBy('createdAt', 'desc'));
      unsubscribeDiesel = onSnapshot(qDiesel, (snapshot) => {
           setDieselEntries(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });

      const qLogs = query(collection(db, 'artifacts', appId, 'public', 'data', 'logs'), orderBy('timestamp', 'desc'));
      unsubscribeLogs = onSnapshot(qLogs, (snapshot) => {
           setLogs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });

      // Production Stock Listeners
      unsubscribeRaw = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'raw_material_stock'), (snapshot) => {
          const stock = {};
          snapshot.forEach(doc => stock[doc.id] = doc.data());
          setRawStock(stock);
      });
      unsubscribeFinished = onSnapshot(collection(db, 'artifacts', appId, 'public', 'data', 'finished_stock'), (snapshot) => {
        const stock = {};
        snapshot.forEach(doc => stock[doc.id] = doc.data());
        setFinishedStock(stock);
    });


    } catch (err) { console.error(err); }
    return () => { unsubscribeOrders(); unsubscribeDiesel(); unsubscribeLogs(); unsubscribeRaw(); unsubscribeFinished(); };
  }, [user]);

  const logAction = async (action, details) => {
    if (!user) return;
    try {
      await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'logs'), {
        action, details, team: role.toUpperCase(), user: user.uid, timestamp: serverTimestamp()
      });
    } catch (err) { console.error("Log failed", err); }
  };

  const showToast = (msg) => { setAppMsg(msg); setTimeout(() => setAppMsg(null), 3000); };

  const handleDateChange = (days) => {
    const parts = viewDate.split('-');
    const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12, 0, 0));
    date.setDate(date.getDate() + days);
    setViewDate(date.toISOString().split('T')[0]);
    setSearchQuery('');
    setFilterMode('date'); 
  };

  // --- REPORT DOWNLOAD HANDLER ---
  const handleDownloadReport = () => {
    if (!isHtml2CanvasReady || !window.html2canvas) {
        showToast("Download tool not ready. Please wait a moment.");
        return;
    }
    
    const reportElement = document.getElementById('report-container');
    if (!reportElement) {
        showToast("Error: Report content not found.");
        return;
    }

    const reportName = productionTab === 'raw-material' 
        ? `RawMaterialStock_${viewDate}` 
        : `DailyProductionReport_${viewDate}`;
    
    showToast("Generating report image...");

    setTimeout(() => {
        window.html2canvas(reportElement, {
            useCORS: true, 
            scrollX: 0, 
            scrollY: -window.scrollY, 
            scale: 2 
        }).then(canvas => {
            const link = document.createElement('a');
            link.download = `${reportName}.png`;
            link.href = canvas.toDataURL('image/png');
            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);
            showToast("Report downloaded successfully.");
        }).catch(err => {
            console.error("Image generation failed:", err);
            showToast("Failed to generate report image.");
        });
    }, 50); 
  };
  
  const handleSearch = (e) => { const val = e.target.value; setSearchQuery(val); if (val) { setFilterMode('search'); if (view !== 'daily-log') setView('daily-log'); } else { setFilterMode('date'); } };
  const injectTestData = async () => { 
    if (!user) return;
    showToast("Generating test data...");
    const todayStr = getTodayString();
    
    // Diesel Entry
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'diesel_entries'), {
      date: todayStr, name: 'Generator 1', location: 'Plant A', driver: 'Operator Raj', hsd: '50',
      createdAt: serverTimestamp()
    });

    // Dispatched Order (Done)
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'orders'), {
      client: `Test Client A`, location: 'Site X', vehicle: 'ABC-9999', transporter: 'ABC',
      size: SIZES[0], cbm: 20, bjm: 5, rate: 4500, bjmRate: 10, status: 'Dispatched', orderDate: todayStr,
      createdBy: user.uid, createdAt: serverTimestamp(), dispatchSlip: 'slip-a.jpg', invoice: 'inv-a.pdf',
      truckType: 12, netWt: 25.000, grossWeight: 35.000, tareWeight: 10.000, loadingBy: 'Team A', unloadingBy: 'Team B', hsd: 120, driverName: 'Driver Singh', tripKm: 450, gsChecked: true, loadingRate: 1900, unloadingRate: 2200
    });

    // Loading Complete Order (Pending Invoice)
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'orders'), {
      client: `Test Client B`, location: 'Site Y', vehicle: 'MH-1000', transporter: 'Logistix',
      size: SIZES[2], cbm: 15, bjm: 3, rate: 5000, bjmRate: 8, status: 'Loading Complete', orderDate: todayStr,
      createdBy: user.uid, createdAt: serverTimestamp(), truckType: 10, loadingRate: 1000, gsChecked: false
    });

    // Invoiced Order (Pending Approval)
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'orders'), {
      client: `Test Client C`, location: 'Site Z', vehicle: 'DL-2000', transporter: 'Freight Co',
      size: SIZES[4], cbm: 30, bjm: 10, rate: 4000, bjmRate: 15, status: 'Invoiced', orderDate: todayStr,
      createdBy: user.uid, createdAt: serverTimestamp(), truckType: 14, loadingRate: 1600, gsChecked: false, invoice: 'inv-c.pdf'
    });

    // Awaiting Truck Order (Loading Queue)
    await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'orders'), {
      client: `Test Client D`, location: 'Site W', vehicle: 'KA-3000', transporter: 'ABC',
      size: SIZES[6], cbm: 22, bjm: 7, rate: 6000, bjmRate: 12, status: 'Awaiting Truck', orderDate: todayStr,
      createdBy: user.uid, createdAt: serverTimestamp(), truckType: 6, loadingRate: 800, unloadingRate: 1000, gsChecked: false
    });

    showToast("Test Data Added.");
  };

  // --- PRODUCTION LOGIC ---

  const getRawMaterialDataForDate = (date) => {
    if (rawStock[date]) return rawStock[date].items;
    const prevDate = getPreviousDateString(date);
    const prevData = rawStock[prevDate]?.items;
    return RAW_MATERIALS_LIST.map((item, index) => {
        const prevClosing = prevData ? safeNum(prevData.find(d => d.desc === item.desc)?.closing) || 0 : 0;
        return {
           id: index, ...item, opening: prevClosing, receipt: 0, total: prevClosing, issue: 0, closing: prevClosing, remarks: ''
        };
    });
  };

  const getFinishedStockDataForDate = (date) => {
    let items = finishedStock[date]?.items;
    const prevDate = getPreviousDateString(date);
    const prevData = finishedStock[prevDate]?.items;
    const prevMortar = finishedStock[prevDate]?.mortarBag;
    const prevSummary = finishedStock[prevDate]?.summary || {}; 

    if (!items) {
        items = FINISHED_STOCK_SIZES.map((size, index) => {
            const prevClosing = prevData ? safeNum(prevData.find(d => d.size === size)?.closing) || 0 : 0;
            return {
                id: index, size, opening: prevClosing, segregation: 0, sale: 0, proRejection: 0, loadingRejection: 0, selfUse: 0, closing: prevClosing
            };
        });
    }
    
    const mortarBag = finishedStock[date]?.mortarBag || {
        opening: prevMortar ? safeNum(prevMortar.closing) : 0,
        receipt: 0, sale: 0, closing: prevMortar ? safeNum(prevMortar.closing) : 0
    };

    const summary = finishedStock[date]?.summary || {
        saleDaily: 0, productionDaily: 0,
        totalSale: prevSummary.totalSale ? safeNum(prevSummary.totalSale) : 0, 
        totalProduction: prevSummary.totalProduction ? safeNum(prevSummary.totalProduction) : 0,
        totalMortarSale: 0 
    };

    return { items, mortarBag, summary };
  };
  
  const updateRawStock = async (index, field, value) => {
    if (field !== 'remarks' && isNaN(Number(value))) { showToast("Please enter a valid number"); return; }
    const currentData = getRawMaterialDataForDate(viewDate);
    const newData = [...currentData];
    newData[index] = { ...newData[index], [field]: field === 'remarks' ? value : safeNum(value) };
    const op = safeNum(newData[index].opening);
    const rec = safeNum(newData[index].receipt);
    const iss = safeNum(newData[index].issue);
    newData[index].total = op + rec;
    newData[index].closing = newData[index].total - iss;
    try {
        await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'raw_material_stock', viewDate), { items: newData, timestamp: serverTimestamp() });
        logAction('STOCK UPDATE', `Updated ${newData[index].desc} stock for ${viewDate}`);
    } catch (e) { console.error(e); showToast("Failed to save stock"); }
  };

  const updateFinishedStock = async (index, field, value) => {
    if (isNaN(Number(value))) { showToast("Please enter a valid number"); return; }
    const { items, mortarBag, summary } = getFinishedStockDataForDate(viewDate);
    const newData = [...items];
    newData[index] = { ...newData[index], [field]: safeNum(value) };
    const op = safeNum(newData[index].opening);
    const seg = safeNum(newData[index].segregation);
    const sale = safeNum(newData[index].sale);
    const pr = safeNum(newData[index].proRejection);
    const lr = safeNum(newData[index].loadingRejection);
    const su = safeNum(newData[index].selfUse);
    newData[index].closing = (op + seg) - (sale + pr + lr + su);
    const newSaleDaily = newData.reduce((acc, item) => acc + safeNum(item.sale), 0);
    const newSummary = { ...summary, saleDaily: newSaleDaily };
    try {
        await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'finished_stock', viewDate), { items: newData, mortarBag, summary: newSummary, timestamp: serverTimestamp() });
        logAction('STOCK UPDATE', `Updated ${newData[index].size} finished stock for ${viewDate}`);
    } catch (e) { console.error(e); showToast("Failed to save stock"); }
  };
  
  const updateMortarBag = async (field, value) => {
    if (isNaN(Number(value))) { showToast("Please enter a valid number"); return; }
      const { items, mortarBag, summary } = getFinishedStockDataForDate(viewDate);
      const newMortar = { ...mortarBag, [field]: safeNum(value) };
      const op = safeNum(newMortar.opening);
      const rec = safeNum(newMortar.receipt); 
      const sale = safeNum(newMortar.sale);
      newMortar.closing = op + rec - sale;
      try {
        await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'finished_stock', viewDate), { items, mortarBag: newMortar, summary, timestamp: serverTimestamp() });
    } catch (e) { console.error(e); showToast("Failed to save mortar stock"); }
  };

  const updateProductionSummary = async (field, value) => {
    if (isNaN(Number(value))) { showToast("Please enter a valid number"); return; }
      const { items, mortarBag, summary } = getFinishedStockDataForDate(viewDate);
      const newSummary = { ...summary, [field]: safeNum(value) };
      try {
        await setDoc(doc(db, 'artifacts', appId, 'public', 'data', 'finished_stock', viewDate), { items, mortarBag, summary: newSummary, timestamp: serverTimestamp() });
    } catch (e) { console.error(e); showToast("Failed to save summary"); }
  };

  const handleEditOrder = (order) => { setEditingOrderId(order.id); setFormData({ client: order.client, location: order.location, vehicle: order.vehicle, transporter: order.transporter || '', size: order.size, cbm: order.cbm, bjm: order.bjm, rate: order.rate, bjmRate: order.bjmRate || '' }); setView('new-order'); };
  const triggerDelete = (orderId) => { setDeleteConfirmId(orderId); };
  const confirmDeleteOrder = async () => { if (!deleteConfirmId) return; try { await deleteDoc(doc(db, 'artifacts', appId, 'public', 'data', 'orders', deleteConfirmId)); logAction('DELETE ORDER', `Deleted Order ID: ${deleteConfirmId}`); showToast("Order deleted"); setDeleteConfirmId(null); } catch (err) { console.error(err); showToast("Failed to delete"); } };
  const handleSubmitOrder = async (e) => { e.preventDefault(); if (!user) return; try { if (editingOrderId) { const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'orders', editingOrderId); await updateDoc(docRef, { ...formData, cbm: Number(formData.cbm), bjm: Number(formData.bjm), rate: Number(formData.rate), bjmRate: Number(formData.bjmRate) }); logAction('UPDATE ORDER', `Updated order for ${formData.client}`); showToast("Order Updated"); setEditingOrderId(null); } else { await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'orders'), { ...formData, cbm: Number(formData.cbm), bjm: Number(formData.bjm), rate: Number(formData.rate), bjmRate: Number(formData.bjmRate), status: 'Awaiting Truck', orderDate: viewDate, createdBy: user.uid, createdAt: serverTimestamp(), dispatchSlip: null, invoice: null, truckType: null, netWt: null, loadingBy: null, unloadingBy: null, hsd: null, loadingRate: 0, unloadingRate: 0, remarks: '', gsChecked: false }); logAction('CREATE ORDER', `Created order for ${formData.client}`); showToast(`Order Created`); } setView('daily-log'); setFilterMode('date'); setSearchQuery(''); setFormData({ client: '', location: '', vehicle: '', transporter: '', size: SIZES[3], cbm: '', bjm: '', rate: '', bjmRate: '' }); } catch (err) { showToast("Operation failed"); } };
  const handleManualDieselSubmit = async (e) => { e.preventDefault(); try { await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'diesel_entries'), { ...manualDieselForm, createdAt: serverTimestamp() }); logAction('DIESEL ENTRY', `Added entry for ${manualDieselForm.name}`); showToast("In-Plant Entry Added"); setManualDieselForm({ date: getTodayString(), name: '', location: '', driver: '', hsd: '' }); } catch (err) { showToast("Failed to add entry"); } };
  const handleBulkImport = async (data) => { try { let count = 0; for (const item of data) { await addDoc(collection(db, 'artifacts', appId, 'public', 'data', 'orders'), { ...item, createdBy: user.uid }); count++; } logAction('BULK IMPORT', `Imported ${count} records from CSV`); showToast(`Successfully imported ${count} records`); setShowImportModal(false); } catch (err) { console.error(err); showToast("Import failed"); } };
  const updateStatus = async (orderId, newStatus, extraData = {}) => { try { const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'orders', orderId); await updateDoc(docRef, { status: newStatus, ...extraData }); logAction('STATUS CHANGE', `Updated Order ${orderId} to ${newStatus}`); showToast(`Status updated`); } catch (err) { showToast("Failed to update status"); } };
  const updateEntry = async (collectionName, id, field, value) => { let finalValue = value; if (['cbm', 'bjm', 'rate', 'bjmRate', 'truckType', 'netWt', 'loadingRate', 'unloadingRate', 'tripKm', 'grossWeight', 'tareWeight', 'piecesLoaded', 'hsd', 'km'].includes(field)) { finalValue = Number(value); if (isNaN(finalValue)) { showToast(`${field} must be a valid number.`); return; } } else if (field === 'hsd') { finalValue = String(value); } try { const docRef = doc(db, 'artifacts', appId, 'public', 'data', collectionName, id); await updateDoc(docRef, { [field]: finalValue }); logAction('INLINE EDIT', `Updated ${field} to ${finalValue} in ${collectionName}`); showToast(`${field} updated!`); } catch (err) { console.error("Update failed", err); showToast("Failed to update field"); } };
  const updateTruckTypeAndRates = async (order, newTypeVal) => { const tType = parseInt(String(newTypeVal).replace(/\D/g, '')); let updates = { truckType: newTypeVal }; let newLoadRate = 0; let newUnloadRate = 0; if (!isNaN(tType) && tType > 0) { const baseLoad = RATE_CARD.loading[tType] || 0; newLoadRate = baseLoad; if (order.gsChecked) { newLoadRate += GS_SURCHARGE; } if (order.transporter && order.transporter.toUpperCase() === 'ABC') { newUnloadRate = RATE_CARD.unloading[tType] || 0; } else { newUnloadRate = 0; } } updates.loadingRate = newLoadRate; updates.unloadingRate = newUnloadRate; try { const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'orders', order.id); await updateDoc(docRef, updates); logAction('RATE UPDATE', `Updated Truck Type/Rates for Order ${order.id}`); showToast("Type & Rates updated"); } catch (err) { console.error("Update failed", err); showToast("Failed to update"); } };
  const toggleGS = async (order) => { const newGSState = !order.gsChecked; let currentLoadRate = Number(order.loadingRate) || 0; let newRate = currentLoadRate; const tType = parseInt(String(order.truckType).replace(/\D/g, '')); if (!isNaN(tType) && tType > 0) { const baseRate = RATE_CARD.loading[tType] || 0; newRate = newGSState ? (baseRate + GS_SURCHARGE) : baseRate; } else { newRate = newGSState ? (currentLoadRate + GS_SURCHARGE) : (currentLoadRate - GS_SURCHARGE); if (newRate < 0) newRate = 0; } try { const docRef = doc(db, 'artifacts', appId, 'public', 'data', 'orders', order.id); await updateDoc(docRef, { gsChecked: newGSState, loadingRate: newRate }); logAction('GS TOGGLE', `Toggled GS for Order ${order.id}`); showToast(newGSState ? "GS Added (+500)" : "GS Removed"); } catch (err) { console.error("Update failed", err); } };
  const handleFileUpload = async (orderId, type, nextStatus) => { const fileName = type === 'dispatchSlip' ? `Slip_${Math.floor(Math.random()*1000)}.jpg` : `Invoice_${Math.floor(Math.random()*1000)}.pdf`; await updateStatus(orderId, nextStatus, { [type]: fileName }); logAction('FILE UPLOAD', `Uploaded ${type} for Order ${orderId}`); };
  const openPreview = (fileType, fileName, orderId = null, canApprove = false) => { const orderData = orders.find(o => o.id === orderId); setPreviewFile({ fileType, fileName, orderId, canApprove, orderData }); };
  const handleApproveFromPreview = async () => { if (previewFile && previewFile.orderId) { await updateStatus(previewFile.orderId, 'Approved'); setPreviewFile(null); } };
  const handleDispatchSubmit = async (orderId, data) => { const slipName = `DS-${orderId.substring(0, 4)}-${Math.floor(Math.random()*1000)}.pdf`; await updateStatus(orderId, 'Dispatched', { ...data, dispatchSlip: slipName }); logAction('DISPATCH', `Dispatched Order ${orderId} with slip ${slipName}`); setDispatchModalOrderId(null); };
  const getStats = () => { const todayStr = getTodayString(); const active = orders.filter(o => ['Loading', 'Truck at Site', 'Loading Complete'].includes(o.status)).length; const pendingInv = orders.filter(o => o.status === 'Loading Complete').length; const pendingApprove = orders.filter(o => o.status === 'Invoiced').length; const todayOrders = orders.filter(o => o.orderDate === todayStr).length; const backlog = orders.filter(o => o.orderDate < todayStr && o.status !== 'Dispatched').length; return { active, pendingInv, pendingApprove, todayOrders, backlog }; };
  const stats = getStats();
  const getDieselRegisterData = () => { const salesData = orders.filter(o => o.hsd).map(o => ({ id: o.id, date: o.orderDate, name: o.client, location: o.location, vehicle: o.vehicle, driver: o.driverName || '', km: o.tripKm || '-', hsd: o.hsd, type: 'Sales', collection: 'orders' })); const manualData = dieselEntries.map(e => ({ id: e.id, date: e.date, name: e.name, location: e.location, vehicle: e.id || '', driver: e.driver, km: e.km || '-', hsd: e.hsd, type: 'In-Plant', collection: 'diesel_entries' })); return [...salesData, ...manualData].sort((a, b) => new Date(b.date) - new Date(a.date)); };
  const getLoadingReportData = () => { return orders.filter(o => o.status === 'Dispatched').sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate)).map(o => { let displayLoadRate = o.loadingRate; let displayUnloadRate = o.unloadingRate; const tType = parseInt(String(o.truckType).replace(/\D/g, '')); if (displayLoadRate === undefined || displayLoadRate === '') { const base = RATE_CARD.loading[tType] || 0; displayLoadRate = o.gsChecked ? (base + GS_SURCHARGE) : base; } if (displayUnloadRate === undefined || displayUnloadRate === '') { if (o.transporter && o.transporter.toUpperCase() === 'ABC' && tType > 0) { displayUnloadRate = RATE_CARD.unloading[tType] || 0; } else { displayUnloadRate = 0; } } return { ...o, displayLoadRate, displayUnloadRate }; }); };
  const getDetailedSalesData = () => { return orders.filter(o => o.status === 'Dispatched').sort((a, b) => new Date(b.orderDate) - new Date(a.orderDate)).map(o => { const cbm = parseFloat(o.cbm) || 0; const rate = parseFloat(o.rate) || 0; const totalBill = (cbm * rate).toFixed(2); let displayLoadRate = o.loadingRate; let displayUnloadRate = o.unloadingRate; const tType = parseInt(String(o.truckType).replace(/\D/g, '')); if (displayLoadRate === undefined || displayLoadRate === '') { const base = RATE_CARD.loading[tType] || 0; displayLoadRate = o.gsChecked ? (base + GS_SURCHARGE) : base; } if (displayUnloadRate === undefined || displayUnloadRate === '') { if (o.transporter && o.transporter.toUpperCase() === 'ABC' && tType > 0) { displayUnloadRate = RATE_CARD.unloading[tType] || 0; } else { displayUnloadRate = 0; } } return { ...o, totalBill, displayLoadRate, displayUnloadRate }; }); };
  let displayedOrders = [];
  if (filterMode === 'search') { const lowerQ = searchQuery.toLowerCase(); displayedOrders = orders.filter(o => o.client.toLowerCase().includes(lowerQ) || o.vehicle.toLowerCase().includes(lowerQ)); } 
  else if (filterMode === 'date') { displayedOrders = orders.filter(o => o.orderDate === viewDate); } 
  else if (filterMode === 'active') { displayedOrders = orders.filter(o => ['Loading', 'Truck at Site', 'Loading Complete'].includes(o.status)); } 
  else if (filterMode === 'approval') { displayedOrders = orders.filter(o => o.status === 'Invoiced'); } 
  else if (filterMode === 'backlog') { const todayStr = getTodayString(); displayedOrders = orders.filter(o => o.orderDate < todayStr && o.status !== 'Dispatched'); } 
  else if (filterMode === 'pending_invoice') { displayedOrders = orders.filter(o => o.status === 'Loading Complete'); }
  const setViewAndFilter = (viewName, mode, date = null) => { setSearchQuery(''); setView(viewName); setFilterMode(mode); if (date) setViewDate(date); };
  const dispatchOrderObj = orders.find(o => o.id === dispatchModalOrderId);

  if (loading) return <div className="flex h-screen items-center justify-center bg-slate-50 text-slate-400">Loading App...</div>;
  if (authError && !user) return <div className="p-10 text-center text-red-500">Connection Error. Please refresh.</div>;

  if (!role) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 space-y-6">
          <div className="text-center"><div className="bg-blue-600 w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-blue-200 shadow-xl"><Package className="text-white w-8 h-8" /></div><h1 className="text-2xl font-bold text-slate-900">AAC Plant Manager</h1><p className="text-slate-500 mt-2">Select your department</p></div>
          <div className="grid gap-3">
            <button onClick={() => setRole('sales')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all group"><div className="bg-blue-100 p-2 rounded-lg"><Briefcase className="text-blue-600 w-5 h-5" /></div><div className="ml-4 text-left"><p className="font-bold text-slate-700">Sales Team</p></div></button>
            <button onClick={() => setRole('loading')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-orange-500 hover:bg-orange-50 transition-all group"><div className="bg-orange-100 p-2 rounded-lg"><Truck className="text-orange-600 w-5 h-5" /></div><div className="ml-4 text-left"><p className="font-bold text-slate-700">Loading Team</p></div></button>
            <button onClick={() => setRole('production')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-cyan-500 hover:bg-cyan-50 transition-all group"><div className="bg-cyan-100 p-2 rounded-lg"><Factory className="text-cyan-600 w-5 h-5" /></div><div className="ml-4 text-left"><p className="font-bold text-slate-700">Production Team</p></div></button>
            <button onClick={() => setRole('accounts')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all group"><div className="bg-green-100 p-2 rounded-lg"><DollarSign className="text-green-600 w-5 h-5" /></div><div className="ml-4 text-left"><p className="font-bold text-slate-700">Accounts</p></div></button>
            <button onClick={() => setRole('management')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-purple-500 hover:bg-purple-50 transition-all group"><div className="bg-purple-100 p-2 rounded-lg"><BarChart3 className="text-purple-600 w-5 h-5" /></div><div className="ml-4 text-left"><p className="font-bold text-slate-700">Management</p></div></button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-20 relative">
      {/* Removed <script> tag for html2canvas to use the useEffect loader */}
      {appMsg && <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-slate-800 text-white px-4 py-2 rounded-full shadow-lg text-sm font-bold animate-bounce">{appMsg}</div>}
      {previewFile && (<DocPreviewModal fileType={previewFile.fileType} fileName={previewFile.fileName} canApprove={previewFile.canApprove} onClose={() => setPreviewFile(null)} onApprove={handleApproveFromPreview} orderData={previewFile.orderData} />)}
      {deleteConfirmId && (<ConfirmModal title="Delete Order?" message="This action cannot be undone. Are you sure?" onConfirm={confirmDeleteOrder} onCancel={() => setDeleteConfirmId(null)} />)}
      {showImportModal && (<ImportModal onClose={() => setShowImportModal(false)} onImport={handleBulkImport} />)}
      {dispatchOrderObj && (<DispatchModal order={dispatchOrderObj} onClose={() => setDispatchModalOrderId(null)} onSubmit={handleDispatchSubmit} logs={logs} />)}

      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2 cursor-pointer shrink-0" onClick={() => setViewAndFilter('home', 'date')}>
            <div className="bg-blue-600 p-1.5 rounded-lg"><Package className="text-white w-4 h-4" /></div><span className="font-bold text-slate-800 hidden md:block">AAC Manager</span><span className="px-2 py-0.5 rounded bg-slate-100 text-slate-500 text-xs font-medium uppercase border border-slate-200">{role}</span>
          </div>
          <div className="flex-1 max-w-md mx-4 relative"><input type="text" placeholder="Search..." className="w-full bg-slate-100 border border-slate-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all" value={searchQuery} onChange={handleSearch} /><Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" /></div>
          <div className="flex items-center space-x-2 shrink-0">
            <button onClick={injectTestData} className="text-slate-400 hover:text-blue-600 p-2" title="Seed Test Data"><FlaskConical className="w-5 h-5" /></button>
            {role === 'sales' && view === 'daily-log' && filterMode === 'date' && viewDate >= getTodayString() && (<button onClick={() => { setEditingOrderId(null); setFormData({ client: '', location: '', vehicle: '', transporter: '', size: SIZES[3], cbm: '', bjm: '', rate: '', bjmRate: '' }); setView('new-order'); }} className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg text-sm font-medium flex items-center shadow-sm whitespace-nowrap"><Plus className="w-4 h-4 md:mr-1.5" /> <span className="hidden md:inline">New Order</span></button>)}
            <button onClick={() => {setRole(null); setView('home');}} className="text-slate-400 hover:text-red-500 p-2"><LogOut className="w-5 h-5" /></button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6">
        {view === 'home' && (
          <div className="space-y-8 animate-in fade-in duration-500">
            <div><h2 className="text-2xl font-bold text-slate-800">Welcome back, {role.toUpperCase()}</h2><p className="text-slate-500">Activity Overview</p></div>
            {/* Role-Based Dashboards */}
            {role === 'sales' && (/* ... existing ... */
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Orders" value={stats.todayOrders} icon={Calendar} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'active')} label="Active Loads" value={stats.active} icon={Truck} colorClass="bg-orange-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'approval')} label="Inv. To Approve" value={stats.pendingApprove} icon={ShieldCheck} colorClass="bg-green-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'backlog')} label="Backlog" value={stats.backlog} icon={AlertTriangle} colorClass="bg-red-500" />
                </div>
            )}
             {role === 'loading' && ( /* ... existing ... */
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Orders" value={stats.todayOrders} icon={Calendar} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'active')} label="Active Loads" value={stats.active} icon={Truck} colorClass="bg-orange-500" />
                </div>
            )}
             {role === 'accounts' && (/* ... existing ... */
               <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Orders" value={stats.todayOrders} icon={Calendar} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'pending_invoice')} label="Pending Invoices" value={stats.pendingInv} icon={FileText} colorClass="bg-red-500" />
               </div>
            )}
            {/* PRODUCTION DASHBOARD WIDGET */}
             {role === 'production' && (
                <div className="grid md:grid-cols-2 gap-4">
                   <Card onClick={() => { setView('production-dashboard'); setProductionTab('raw-material'); }} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><Layers className="w-5 h-5 text-cyan-600 mr-2"/><span className="font-bold text-lg">Raw Material Stock</span></div><p className="text-sm text-slate-500">Manage raw material inventory.</p></div><ArrowRight className="text-slate-300 group-hover:text-cyan-600"/></Card>
                   <Card onClick={() => { setView('production-dashboard'); setProductionTab('finished-stock'); }} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><Boxes className="w-5 h-5 text-indigo-600 mr-2"/><span className="font-bold text-lg">Daily Production Report</span></div><p className="text-sm text-slate-500">Track finished goods & daily output.</p></div><ArrowRight className="text-slate-300 group-hover:text-indigo-600"/></Card>
                </div>
            )}

            {role === 'management' && (
              <>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Activity" value={stats.todayOrders} icon={Calendar} colorClass="bg-purple-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'active')} label="Active Trucks" value={stats.active} icon={Truck} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'pending_invoice')} label="Billing Pending" value={stats.pendingInv} icon={AlertCircle} colorClass="bg-red-500" />
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mt-8">
                   <Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><BarChart3 className="w-5 h-5 text-purple-600 mr-2"/><span className="font-bold text-lg">Daily Activity</span></div><p className="text-sm text-slate-500">View all dispatch records.</p></div><ArrowRight className="text-slate-300 group-hover:text-purple-600"/></Card>
                   <Card onClick={() => setView('production-dashboard')} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><Factory className="w-5 h-5 text-cyan-600 mr-2"/><span className="font-bold text-lg">Production Stock</span></div><p className="text-sm text-slate-500">Raw Material & Inventory.</p></div><ArrowRight className="text-slate-300 group-hover:text-cyan-600"/></Card>
                   <Card onClick={() => setView('diesel-register')} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><Fuel className="w-5 h-5 text-orange-600 mr-2"/><span className="font-bold text-lg">Diesel Register</span></div><p className="text-sm text-slate-500">Track HSD usage.</p></div><ArrowRight className="text-slate-300 group-hover:text-orange-600"/></Card>
                   <Card onClick={() => setView('loading-report')} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><ClipboardList className="w-5 h-5 text-blue-600 mr-2"/><span className="font-bold text-lg">Labor Report</span></div><p className="text-sm text-slate-500">Rates & remarks.</p></div><ArrowRight className="text-slate-300 group-hover:text-blue-600"/></Card>
                   <Card onClick={() => setView('detailed-sales-report')} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><FileSpreadsheet className="w-5 h-5 text-green-600 mr-2"/><span className="font-bold text-lg">Sales Report</span></div><p className="text-sm text-slate-500">Full details with Bill Amt.</p></div><ArrowRight className="text-slate-300 group-hover:text-green-600"/></Card>
                   <Card onClick={() => setView('system-logs')} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><ScrollText className="w-5 h-5 text-slate-600 mr-2"/><span className="font-bold text-lg">System Logs</span></div><p className="text-sm text-slate-500">Audit trail of changes.</p></div><ArrowRight className="text-slate-300 group-hover:text-slate-600"/></Card>
                </div>
              </>
            )}
            {/* ... existing module links for other roles ... */}
             {role === 'sales' && (<div className="grid md:grid-cols-2 gap-4 mt-8"><Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><LayoutGrid className="w-5 h-5 text-blue-600 mr-2"/><span className="font-bold text-lg">Daily Loading Plan</span></div><p className="text-sm text-slate-500">Manage schedules & invoices.</p></div><ArrowRight className="text-slate-300 group-hover:text-blue-600"/></Card><Card onClick={() => { setViewDate(getTodayString()); setEditingOrderId(null); setFormData({ client: '', location: '', vehicle: '', transporter: '', size: SIZES[3], cbm: '', bjm: '', rate: '', bjmRate: '' }); setView('new-order'); }} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><Plus className="w-5 h-5 text-green-600 mr-2"/><span className="font-bold text-lg">Create New Order</span></div><p className="text-sm text-slate-500">Add loading requirement.</p></div><ArrowRight className="text-slate-300 group-hover:text-green-600"/></Card><Card onClick={() => setView('detailed-sales-report')} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><FileSpreadsheet className="w-5 h-5 text-blue-600 mr-2"/><span className="font-bold text-lg">Daily Sales Log</span></div><p className="text-sm text-slate-500">View comprehensive sales data.</p></div><ArrowRight className="text-slate-300 group-hover:text-blue-600"/></Card></div>)}
             {role === 'loading' && (<div className="grid md:grid-cols-1 gap-4 mt-8"><Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><LayoutGrid className="w-5 h-5 text-orange-600 mr-2"/><span className="font-bold text-lg">Daily Loading Log</span></div><p className="text-sm text-slate-500">Update truck status & dispatch.</p></div><ArrowRight className="text-slate-300 group-hover:text-orange-600"/></Card></div>)}
             {role === 'accounts' && (<div className="grid md:grid-cols-1 gap-4 mt-8"><Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><LayoutGrid className="w-5 h-5 text-green-600 mr-2"/><span className="font-bold text-lg">Loading & Billing</span></div><p className="text-sm text-slate-500">Upload tax invoices.</p></div><ArrowRight className="text-slate-300 group-hover:text-green-600"/></Card><Card onClick={() => setView('detailed-sales-report')} className="p-6 flex items-center justify-between group cursor-pointer"><div><div className="flex items-center mb-2"><FileSpreadsheet className="w-5 h-5 text-green-600 mr-2"/><span className="font-bold text-lg">Daily Sales Log</span></div><p className="text-sm text-slate-500">View comprehensive sales data.</p></div><ArrowRight className="text-slate-300 group-hover:text-green-600"/></Card></div>)}
          </div>
        )}

        {/* --- PRODUCTION DASHBOARD --- */}
        {view === 'production-dashboard' && (
            <div className="space-y-8">
                {/* Date Navigation & Actions */}
                <div className="flex items-center justify-between bg-white p-3 rounded-xl shadow-sm border border-slate-200">
                   <button onClick={() => handleDateChange(-1)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"><ChevronLeft className="w-5 h-5" /></button>
                   <div className="flex flex-col items-center">
                     <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">Production Log</span>
                     <span className="text-lg font-bold text-slate-800 flex items-center gap-2"><Calendar className="w-4 h-4 text-blue-500" />{formatDateDisplay(viewDate)}</span>
                   </div>
                   
                   <button 
                        onClick={handleDownloadReport} 
                        disabled={!isHtml2CanvasReady}
                        className="bg-green-600 hover:bg-green-700 text-white px-3 py-2 rounded-lg text-sm font-bold flex items-center shadow-sm disabled:opacity-50 disabled:cursor-not-allowed"
                    >
                        {isHtml2CanvasReady ? <><Download className="w-4 h-4 mr-1.5" /> Download {productionTab === 'raw-material' ? 'RM Stock' : 'Prod. Report'}</> : 'Loading Tool...'}
                    </button>

                   <button onClick={() => handleDateChange(1)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"><ChevronRight className="w-5 h-5" /></button>
                </div>

                {/* Tabs Navigation */}
                <div className="flex space-x-4 border-b border-slate-200 pb-1">
                    <button 
                        onClick={() => setProductionTab('raw-material')} 
                        className={`px-4 py-2 text-sm font-bold rounded-t-lg transition-colors ${productionTab === 'raw-material' ? 'bg-cyan-50 text-cyan-700 border-b-2 border-cyan-600' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}
                    >
                        Raw Material Stock
                    </button>
                    <button 
                        onClick={() => setProductionTab('finished-stock')} 
                        className={`px-4 py-2 text-sm font-bold rounded-t-lg transition-colors ${productionTab === 'finished-stock' ? 'bg-indigo-50 text-indigo-700 border-b-2 border-indigo-600' : 'text-slate-500 hover:text-slate-700 hover:bg-slate-50'}`}
                    >
                        Daily Production Report
                    </button>
                </div>

                {/* Report Container for HTML2Canvas */}
                <div id="report-container" className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden px-6 pt-6 pb-12"> 
                    {/* 1.1 Raw Material Stock */}
                    {productionTab === 'raw-material' && (
                        <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                            <div className="flex flex-col justify-between items-center text-center mb-6">
                                <span className="font-extrabold text-lg text-cyan-900 mb-1">ABC ASHPRO</span>
                                <div className="w-full max-w-sm border-b-2 border-cyan-800 mb-2"></div>
                                <h3 className="font-bold text-cyan-800 text-lg">STATUS OF RAW MATERIAL</h3>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left whitespace-nowrap">
                                    <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-xs">
                                            <tr>
                                                <th className="px-4 py-3 text-center">Sr No</th>
                                                <th className="px-4 py-3 text-center">Description</th>
                                                <th className="px-4 py-3 text-center">Unit</th>
                                                <th className="px-4 py-3 text-center bg-blue-50/50">Opening</th>
                                                <th className="px-4 py-3 text-center bg-blue-50/50">Receipt</th>
                                                <th className="px-4 py-3 text-center font-extrabold bg-blue-100/50">Total</th>
                                                <th className="px-4 py-3 text-center bg-orange-50/50">Issue</th>
                                                <th className="px-4 py-3 text-center font-extrabold bg-green-100/50">Closing</th>
                                                <th className="px-4 py-3 text-center">Remarks</th>
                                            </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                            {getRawMaterialDataForDate(viewDate).map((item, idx) => (
                                                <tr key={idx} className="hover:bg-slate-50">
                                                    <td className="px-4 py-2 text-slate-500 text-center">{idx + 1}</td>
                                                    <td className="px-4 py-2 font-bold text-slate-700 text-left">{item.desc}</td>
                                                    <td className="px-4 py-2 text-slate-500 text-xs text-center">{item.unit}</td>
                                                    <td className="px-4 py-2 text-right font-bold text-slate-700 bg-slate-50/30">{item.opening.toFixed(2)}</td>
                                                    <td className="px-4 py-2"><EditableCell type="text" inputMode="decimal" className="text-right font-bold text-slate-700" value={item.receipt} onUpdate={v => updateRawStock(idx, 'receipt', v)} tableId="raw-material" rowIndex={idx} colIndex={0} /></td>
                                                    <td className="px-4 py-2 text-right font-bold text-blue-700 bg-blue-50/30">{item.total.toFixed(2)}</td>
                                                    <td className="px-4 py-2"><EditableCell type="text" inputMode="decimal" className="text-right font-bold text-slate-700" value={item.issue} onUpdate={v => updateRawStock(idx, 'issue', v)} tableId="raw-material" rowIndex={idx} colIndex={1} /></td>
                                                    <td className="px-4 py-2 text-right font-bold text-green-700 bg-green-50/30">{item.closing.toFixed(2)}</td>
                                                    <td className="px-4 py-2"><EditableCell type="text" value={item.remarks} className="text-left font-bold text-slate-700" onUpdate={v => updateRawStock(idx, 'remarks', v)} tableId="raw-material" rowIndex={idx} colIndex={2} /></td>
                                                </tr>
                                            ))}
                                            {/* TOTALS ROW - RAW MATERIAL */}
                                            <tr className="bg-slate-100 font-bold text-slate-900">
                                                <td colSpan="3" className="px-4 py-3 text-right text-xs uppercase">Total</td>
                                                <td className="px-4 py-3 text-right bg-blue-100/50">{calculateColumnTotal(getRawMaterialDataForDate(viewDate), 'opening')}</td>
                                                <td className="px-4 py-3 text-right bg-blue-100/50">{calculateColumnTotal(getRawMaterialDataForDate(viewDate), 'receipt')}</td>
                                                <td className="px-4 py-3 text-right bg-blue-200/50">{calculateColumnTotal(getRawMaterialDataForDate(viewDate), 'total')}</td>
                                                <td className="px-4 py-3 text-right bg-orange-100/50">{calculateColumnTotal(getRawMaterialDataForDate(viewDate), 'issue')}</td>
                                                <td className="px-4 py-3 text-right bg-green-200/50">{calculateColumnTotal(getRawMaterialDataForDate(viewDate), 'closing')}</td>
                                                <td className="px-4 py-3"></td>
                                            </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    )}

                    {/* Finished Stock */}
                    {productionTab === 'finished-stock' && (
                        <div className="animate-in fade-in slide-in-from-bottom-4 duration-300">
                            <div className="flex flex-col justify-between items-center text-center mb-6">
                                <span className="font-extrabold text-lg text-indigo-900 mb-1">ABC ASHPRO</span>
                                <div className="w-full max-w-sm border-b-2 border-indigo-800 mb-2"></div>
                                 <h3 className="font-bold text-indigo-800 text-lg">FINISHED STOCK REPORT</h3>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-sm text-left whitespace-nowrap">
                                    <thead className="bg-slate-50 text-slate-600 font-bold uppercase text-xs">
                                            <tr>
                                                <th className="px-4 py-3 text-center">SL No</th>
                                                <th className="px-4 py-3 text-center">Size</th>
                                                <th className="px-4 py-3 text-center bg-blue-50/50">Opening (CBM)</th>
                                                <th className="px-4 py-3 text-center bg-green-50/50">Segregation (CBM)</th>
                                                <th className="px-4 py-3 text-center bg-orange-50/50">Sale (CBM)</th>
                                                <th className="px-4 py-3 text-center bg-red-50/50">Pro Rejection (CBM)</th>
                                                <th className="px-4 py-3 text-center bg-red-50/50">Load Rejection (CBM)</th>
                                                <th className="px-4 py-3 text-center bg-yellow-50/50">Self Use & Others (CBM)</th>
                                                <th className="px-4 py-3 text-center font-extrabold bg-indigo-100/50">Closing (CBM)</th>
                                            </tr>
                                    </thead>
                                    <tbody className="divide-y divide-slate-100">
                                            {getFinishedStockDataForDate(viewDate).items.map((item, idx) => (
                                                <tr key={idx} className="hover:bg-slate-50">
                                                    <td className="px-4 py-2 text-slate-500 text-center">{idx + 1}</td>
                                                    <td className="px-4 py-2 font-bold text-slate-900 text-xs text-left">{item.size}</td>
                                                    <td className="px-4 py-2 text-right font-mono text-slate-600 bg-slate-50/30">{item.opening.toFixed(2)}</td>
                                                    <td className="px-4 py-2"><EditableCell type="text" inputMode="decimal" className="text-right font-bold text-slate-700" value={item.segregation} onUpdate={v => updateFinishedStock(idx, 'segregation', v)} tableId="finished-stock" rowIndex={idx} colIndex={0} /></td>
                                                    <td className="px-4 py-2"><EditableCell type="text" inputMode="decimal" className="text-right font-bold text-slate-700" value={item.sale} onUpdate={v => updateFinishedStock(idx, 'sale', v)} tableId="finished-stock" rowIndex={idx} colIndex={1} /></td>
                                                    <td className="px-4 py-2"><EditableCell type="text" inputMode="decimal" className="text-right font-bold text-slate-700" value={item.proRejection} onUpdate={v => updateFinishedStock(idx, 'proRejection', v)} tableId="finished-stock" rowIndex={idx} colIndex={2} /></td>
                                                    <td className="px-4 py-2"><EditableCell type="text" inputMode="decimal" className="text-right font-bold text-slate-700" value={item.loadingRejection} onUpdate={v => updateFinishedStock(idx, 'loadingRejection', v)} tableId="finished-stock" rowIndex={idx} colIndex={3} /></td>
                                                    <td className="px-4 py-2"><EditableCell type="text" inputMode="decimal" className="text-right font-bold text-slate-700" value={item.selfUse} onUpdate={v => updateFinishedStock(idx, 'selfUse', v)} tableId="finished-stock" rowIndex={idx} colIndex={4} /></td>
                                                    <td className="px-4 py-2 text-right font-bold text-indigo-700 bg-indigo-50/30">{item.closing.toFixed(2)}</td>
                                                </tr>
                                            ))}
                                            {/* TOTALS ROW - FINISHED STOCK */}
                                            <tr className="bg-slate-200 font-bold text-slate-900 border-t-2 border-slate-300">
                                                <td colSpan="2" className="px-4 py-3 text-right text-xs uppercase">TOTAL (CBM)</td>
                                                <td className="px-4 py-3 text-right bg-blue-200/50">{calculateColumnTotal(getFinishedStockDataForDate(viewDate).items, 'opening')}</td>
                                                <td className="px-4 py-3 text-right bg-green-200/50">{calculateColumnTotal(getFinishedStockDataForDate(viewDate).items, 'segregation')}</td>
                                                <td className="px-4 py-3 text-right bg-orange-200/50">{calculateColumnTotal(getFinishedStockDataForDate(viewDate).items, 'sale')}</td>
                                                <td className="px-4 py-3 text-right bg-red-200/50">{calculateColumnTotal(getFinishedStockDataForDate(viewDate).items, 'proRejection')}</td>
                                                <td className="px-4 py-3 text-right bg-red-200/50">{calculateColumnTotal(getFinishedStockDataForDate(viewDate).items, 'loadingRejection')}</td>
                                                <td className="px-4 py-3 text-right bg-yellow-200/50">{calculateColumnTotal(getFinishedStockDataForDate(viewDate).items, 'selfUse')}</td>
                                                <td className="px-4 py-3 text-right bg-indigo-300/50">{calculateColumnTotal(getFinishedStockDataForDate(viewDate).items, 'closing')}</td>
                                            </tr>
                                            {/* MORTAR BAG ROW (SEPARATE) */}
                                            <tr className="bg-yellow-50 font-bold border-t border-yellow-200">
                                                <td className="px-4 py-3 text-center text-yellow-700">1</td>
                                                <td className="px-4 py-3 text-left text-yellow-900">MORTAR (BAG)</td>
                                                <td className="px-4 py-3 text-right font-mono text-slate-600 bg-yellow-100/50">{getFinishedStockDataForDate(viewDate).mortarBag.opening}</td>
                                                <td className="px-4 py-3"><EditableCell type="text" inputMode="decimal" className="text-right bg-white/50 font-bold text-slate-700" value={getFinishedStockDataForDate(viewDate).mortarBag.receipt} onUpdate={v => updateMortarBag('receipt', v)} tableId="finished-stock" rowIndex={FINISHED_STOCK_SIZES.length} colIndex={0} /></td>
                                                <td className="px-4 py-3"><EditableCell type="text" inputMode="decimal" className="text-right bg-white/50 font-bold text-slate-700" value={getFinishedStockDataForDate(viewDate).mortarBag.sale} onUpdate={v => updateMortarBag('sale', v)} tableId="finished-stock" rowIndex={FINISHED_STOCK_SIZES.length} colIndex={1} /></td>
                                                <td colSpan="3" className="px-4 py-3 text-center text-xs text-slate-400 italic bg-yellow-50/50">N/A</td>
                                                <td className="px-4 py-3 text-right text-indigo-700 font-extrabold bg-yellow-100/50">{getFinishedStockDataForDate(viewDate).mortarBag.closing}</td>
                                            </tr>
                                    </tbody>
                                </table>

                                {/* NEW SUMMARY SECTION & FOOTER */}
                                <div className="p-6 bg-white border-t border-slate-200 mt-4">
                                    <div className="flex justify-between items-start gap-8 mb-6">
                                            {/* Left Summary Table */}
                                            <div className="w-1/2 border border-slate-300">
                                                <div className="flex bg-slate-100 border-b border-slate-300 text-xs font-bold">
                                                    <div className="flex-1 p-2 border-r border-slate-300">SALE</div>
                                                    <div className="w-24 p-2 border-r border-slate-300 text-center">CBM</div>
                                                    <div className="w-32 p-2 text-right bg-orange-50 font-bold text-slate-800">{getFinishedStockDataForDate(viewDate).summary.saleDaily}</div>
                                                </div>
                                                <div className="flex border-b border-slate-300 text-xs font-bold">
                                                    <div className="flex-1 p-2 border-r border-slate-300">TOTAL SALE</div>
                                                    <div className="w-24 p-2 border-r border-slate-300 text-center">CBM</div>
                                                    <div className="w-32 p-0 bg-white"><EditableCell type="text" inputMode="decimal" className="text-right font-bold h-full text-slate-800" value={getFinishedStockDataForDate(viewDate).summary.totalSale} onUpdate={v => updateProductionSummary('totalSale', v)} /></div>
                                                </div>
                                                <div className="flex text-xs font-bold bg-yellow-50">
                                                    <div className="flex-1 p-2 border-r border-slate-300">TOTAL MORTAR SALE</div>
                                                    <div className="w-24 p-2 border-r border-slate-300 text-center">BAGS</div>
                                                    <div className="w-32 p-0"><EditableCell type="text" inputMode="decimal" className="text-right font-bold h-full bg-transparent text-slate-800" value={getFinishedStockDataForDate(viewDate).summary.totalMortarSale} onUpdate={v => updateProductionSummary('totalMortarSale', v)} /></div>
                                                </div>
                                            </div>

                                            {/* Right Summary Table */}
                                            <div className="w-1/2 border border-slate-300">
                                                <div className="flex bg-slate-100 border-b border-slate-300 text-xs font-bold">
                                                    <div className="flex-1 p-2 border-r border-slate-300">PRODUCTION</div>
                                                    <div className="w-24 p-2 border-r border-slate-300 text-center">CBM</div>
                                                    <div className="w-32 p-0 bg-white"><EditableCell type="text" inputMode="decimal" className="text-right font-bold h-full bg-transparent text-slate-800" value={getFinishedStockDataForDate(viewDate).summary.productionDaily} onUpdate={v => updateProductionSummary('productionDaily', v)} /></div>
                                                </div>
                                                <div className="flex text-xs font-bold">
                                                    <div className="flex-1 p-2 border-r border-slate-300">TOTAL PRODUCTION</div>
                                                    <div className="w-24 p-2 border-r border-slate-300 text-center">CBM</div>
                                                    <div className="w-32 p-0 bg-white"><EditableCell type="text" inputMode="decimal" className="text-right font-bold h-full text-slate-800" value={getFinishedStockDataForDate(viewDate).summary.totalProduction} onUpdate={v => updateProductionSummary('totalProduction', v)} /></div>
                                                </div>
                                            </div>
                                    </div>

                                    {/* Footer Signatures */}
                                    <div className="flex justify-between items-end pt-12 pb-4 text-sm font-bold text-slate-800">
                                            <div className="flex flex-col gap-2">
                                                <span className="underline decoration-2 underline-offset-4">Prepared by</span>
                                            </div>
                                            <div className="flex flex-col gap-2">
                                                <span className="underline decoration-2 underline-offset-4">Checked by</span>
                                            </div>
                                            <div className="flex flex-col gap-2">
                                                <span className="underline decoration-2 underline-offset-4">Approved by</span>
                                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    )}
                </div> {/* End of #report-container */}
            </div>
        )}

        {/* --- SYSTEM LOGS VIEW (Management) --- */}
        {view === 'system-logs' && (
           <div className="space-y-6">
             <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-slate-200"><div><h2 className="text-lg font-bold text-slate-800 flex items-center gap-2"><History className="w-5 h-5 text-slate-600"/> System Audit Logs</h2><p className="text-xs text-slate-400">Real-time activity tracking.</p></div></div>
             <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"><table className="w-full text-sm text-left"><thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs"><tr><th className="px-4 py-3">Time</th><th className="px-4 py-3">Team</th><th className="px-4 py-3">Action</th><th className="px-4 py-3">Details</th></tr></thead><tbody className="divide-y divide-slate-100">{logs.map(log => (<tr key={log.id} className="hover:bg-slate-50"><td className="px-4 py-2 text-slate-500 whitespace-nowrap text-xs">{formatDateTimeDisplay(log.timestamp)}</td><td className="px-4 py-2 font-bold text-slate-700 text-xs">{log.team}</td><td className="px-4 py-2"><span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">{log.action}</span></td><td className="px-4 py-2 text-slate-600">{log.details}</td></tr>))}</tbody></table></div>
           </div>
        )}
        
        {/* --- LOADING & UNLOADING REPORT VIEW --- */}
        {view === 'loading-report' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-slate-200">
               <div><h2 className="text-lg font-bold text-slate-800 flex items-center gap-2"><ClipboardList className="w-5 h-5 text-blue-600"/> Loading & Unloading Report</h2><p className="text-xs text-slate-400">Labor and Rates tracking for dispatched orders</p></div>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
               <div className="overflow-x-auto">
                 <table className="w-full text-sm text-left">
                   <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs"><tr><th className="px-4 py-3">Date</th><th className="px-4 py-3">Client</th><th className="px-4 py-3">Vehicle</th><th className="px-4 py-3">Type</th><th className="px-4 py-3 text-center w-12">GS</th><th className="px-4 py-3">Loading By</th><th className="px-4 py-3 w-24 text-right">Load Rate</th><th className="px-4 py-3">Unloading By</th><th className="px-4 py-3 w-24 text-right">Unload Rate</th><th className="px-4 py-3">Remarks</th></tr></thead>
                   <tbody className="divide-y divide-slate-100">
                     {getLoadingReportData().map((order) => (
                       <tr key={order.id} className="hover:bg-slate-50 transition-colors">
                         <td className="px-4 py-3"><EditableCell value={order.orderDate} type="date" onUpdate={(v) => updateEntry('orders', order.id, 'orderDate', v)} /></td>
                         <td className="px-4 py-3"><EditableCell value={order.client} onUpdate={(v) => updateEntry('orders', order.id, 'client', v)} /></td>
                         <td className="px-4 py-3"><EditableCell value={order.vehicle} className="font-mono" onUpdate={(v) => updateEntry('orders', order.id, 'vehicle', v)} /></td>
                         <td className="px-4 py-3">
                           <EditableCell value={order.truckType} type="number" onUpdate={(v) => updateTruckTypeAndRates(order, v)} />
                         </td>
                         <td className="px-4 py-3 text-center"><input type="checkbox" checked={order.gsChecked || false} onChange={() => toggleGS(order)} className="w-4 h-4 text-blue-600 rounded border-slate-300 focus:ring-blue-500 cursor-pointer"/></td>
                         <td className="px-4 py-3"><EditableCell value={order.loadingBy} onUpdate={(v) => updateEntry('orders', order.id, 'loadingBy', v)} /></td>
                         <td className="px-4 py-3"><EditableCell value={order.displayLoadRate} type="number" className="text-right" onUpdate={(v) => updateEntry('orders', order.id, 'loadingRate', safeInt(v))} /></td>
                         <td className="px-4 py-3"><EditableCell value={order.unloadingBy} onUpdate={(v) => updateEntry('orders', order.id, 'unloadingBy', v)} /></td>
                         <td className="px-4 py-3"><EditableCell value={order.displayUnloadRate} type="number" className="text-right" onUpdate={(v) => updateEntry('orders', order.id, 'unloadingRate', safeInt(v))} /></td>
                         <td className="px-4 py-3"><EditableCell value={order.remarks} onUpdate={(v) => updateEntry('orders', order.id, 'remarks', v)} /></td>
                       </tr>
                     ))}
                   </tbody>
                 </table>
               </div>
            </div>
          </div>
        )}
        
        {/* --- DETAILED SALES REPORT VIEW (Management/Sales/Accounts) --- */}
        {view === 'detailed-sales-report' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-slate-200"><div><h2 className="text-lg font-bold text-slate-800 flex items-center gap-2"><FileSpreadsheet className="w-5 h-5 text-green-600"/> Detailed Sales Report</h2><p className="text-xs text-slate-400">Comprehensive log with billing details</p></div></div>
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"><div className="overflow-x-auto"><table className="w-full text-sm text-left whitespace-nowrap"><thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs"><tr><th className="px-4 py-3">Date</th><th className="px-4 py-3">Invoice No</th><th className="px-4 py-3 text-center">Inv. File</th><th className="px-4 py-3">Client</th><th className="px-4 py-3">Site</th><th className="px-4 py-3 text-right">CBM</th><th className="px-4 py-3 text-right">BJM</th><th className="px-4 py-3 text-right">BJM Rate</th><th className="px-4 py-3 text-right">Bill Amt</th><th className="px-4 py-3">Vehicle</th><th className="px-4 py-3">Type</th><th className="px-4 py-3">Transporter</th><th className="px-4 py-3 text-right">Net Wt</th><th className="px-4 py-3">Loading</th><th className="px-4 py-3 text-right">L. Rate</th><th className="px-4 py-3">Unloading</th><th className="px-4 py-3 text-right">U. Rate</th><th className="px-4 py-3 text-center">GS</th><th className="px-4 py-3">Ref</th></tr></thead><tbody className="divide-y divide-slate-100">{getDetailedSalesData().map((order, idx) => (<tr key={order.id} className="hover:bg-slate-50 transition-colors"><td className="px-4 py-3"><EditableCell value={order.orderDate} type="date" onUpdate={(v) => updateEntry('orders', order.id, 'orderDate', v)} tableId="sales-report" rowIndex={idx} colIndex={0} /></td><td className="px-4 py-3"><EditableCell value={order.invoiceNumber} onUpdate={(v) => updateEntry('orders', order.id, 'invoiceNumber', v)} tableId="sales-report" rowIndex={idx} colIndex={1} /></td><td className="px-4 py-3 text-center">{order.invoice ? (<button onClick={() => openPreview('invoice', order.invoice)} className="text-indigo-600 hover:underline text-xs">View</button>) : <span className="text-slate-300">-</span>}</td><td className="px-4 py-3"><EditableCell value={order.client} onUpdate={(v) => updateEntry('orders', order.id, 'client', v)} tableId="sales-report" rowIndex={idx} colIndex={2} /></td><td className="px-4 py-3"><EditableCell value={order.location} onUpdate={(v) => updateEntry('orders', order.id, 'location', v)} tableId="sales-report" rowIndex={idx} colIndex={3} /></td><td className="px-4 py-3"><EditableCell value={order.cbm} type="text" inputMode="decimal" className="text-right font-mono" onUpdate={(v) => updateEntry('orders', order.id, 'cbm', v)} tableId="sales-report" rowIndex={idx} colIndex={4} /></td><td className="px-4 py-3"><EditableCell value={order.bjm} type="text" inputMode="decimal" className="text-right font-mono" onUpdate={(v) => updateEntry('orders', order.id, 'bjm', v)} tableId="sales-report" rowIndex={idx} colIndex={5} /></td><td className="px-4 py-3"><EditableCell value={order.bjmRate} type="text" inputMode="decimal" className="text-right font-mono" onUpdate={(v) => updateEntry('orders', order.id, 'bjmRate', v)} tableId="sales-report" rowIndex={idx} colIndex={6} /></td><td className="px-4 py-3 text-right font-bold text-slate-800">₹ {order.totalBill}</td><td className="px-4 py-3"><EditableCell value={order.vehicle} className="font-mono" onUpdate={(v) => updateEntry('orders', order.id, 'vehicle', v)} tableId="sales-report" rowIndex={idx} colIndex={7} /></td><td className="px-4 py-3"><EditableCell value={order.truckType} type="text" inputMode="decimal" onUpdate={(v) => updateTruckTypeAndRates(order, v)} tableId="sales-report" rowIndex={idx} colIndex={8} /></td><td className="px-4 py-3"><EditableCell value={order.transporter} onUpdate={(v) => updateEntry('orders', order.id, 'transporter', v)} tableId="sales-report" rowIndex={idx} colIndex={9} /></td><td className="px-4 py-3"><EditableCell value={order.netWt} type="text" inputMode="decimal" className="text-right font-mono" onUpdate={(v) => updateEntry('orders', order.id, 'netWt', v)} tableId="sales-report" rowIndex={idx} colIndex={10} /></td><td className="px-4 py-3"><EditableCell value={order.loadingBy} onUpdate={(v) => updateEntry('orders', order.id, 'loadingBy', v)} tableId="sales-report" rowIndex={idx} colIndex={11} /></td><td className="px-4 py-3"><EditableCell value={order.displayLoadRate} type="text" inputMode="decimal" className="text-right" onUpdate={(v) => updateEntry('orders', order.id, 'loadingRate', safeInt(v))} tableId="sales-report" rowIndex={idx} colIndex={12} /></td><td className="px-4 py-3"><EditableCell value={order.unloadingBy} onUpdate={(v) => updateEntry('orders', order.id, 'unloadingBy', v)} tableId="sales-report" rowIndex={idx} colIndex={13} /></td><td className="px-4 py-3"><EditableCell value={order.displayUnloadRate} type="text" inputMode="decimal" className="text-right" onUpdate={(v) => updateEntry('orders', order.id, 'unloadingRate', safeInt(v))} tableId="sales-report" rowIndex={idx} colIndex={14} /></td><td className="px-4 py-3 text-center"><input type="checkbox" checked={order.gsChecked || false} onChange={() => toggleGS(order)} className="w-4 h-4 text-green-600 rounded border-slate-300 focus:ring-green-500 cursor-pointer"/></td><td className="px-4 py-3"><EditableCell value={order.reference} onUpdate={(v) => updateEntry('orders', order.id, 'reference', v)} tableId="sales-report" rowIndex={idx} colIndex={15} /></td></tr>))}</tbody></table></div></div>
          </div>
        )}

        {/* --- DIESEL REGISTER VIEW --- */}
        {view === 'diesel-register' && (
           <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
             <div className="lg:col-span-2 space-y-6">
               <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-slate-200"><div><h2 className="text-lg font-bold text-slate-800 flex items-center gap-2"><Fuel className="w-5 h-5 text-orange-600"/> Diesel Usage Register</h2><p className="text-xs text-slate-400">Combined log of Transport & Plant Machinery</p></div></div>
               <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden"><div className="overflow-x-auto"><table className="w-full text-sm text-left"><thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs"><tr><th className="px-4 py-3">Date</th><th className="px-4 py-3">Client / Machine</th><th className="px-4 py-3">Loc / Site</th><th className="px-4 py-3">Vehicle / ID</th><th className="px-4 py-3">Operator / Issued To</th><th className="px-4 py-3">KM / Hrs</th><th className="px-4 py-3 text-right">HSD (L)</th></tr></thead><tbody className="divide-y divide-slate-100">{getDieselRegisterData().map((entry) => (<tr key={entry.id} className="hover:bg-slate-50 transition-colors"><td className="px-4 py-3 font-medium text-slate-800 whitespace-nowrap"><EditableCell value={entry.date} type="date" onUpdate={(v) => updateEntry(entry.collection, entry.id, entry.collection === 'orders' ? 'orderDate' : 'date', v)} /></td><td className="px-4 py-3 text-slate-700"><EditableCell value={entry.name} onUpdate={(v) => updateEntry(entry.collection, entry.id, entry.collection === 'orders' ? 'client' : 'name', v)} />{entry.type === 'In-Plant' && <span className="text-[9px] bg-orange-100 text-orange-700 px-1.5 py-0.5 rounded uppercase tracking-wider ml-1">Plant</span>}</td><td className="px-4 py-3 text-slate-500"><EditableCell value={entry.location} onUpdate={(v) => updateEntry(entry.collection, entry.id, 'location', v)} /></td><td className="px-4 py-3 font-mono text-slate-600 text-xs"><EditableCell value={entry.vehicle} onUpdate={(v) => updateEntry(entry.collection, entry.id, entry.collection === 'orders' ? 'vehicle' : 'id', v)} /></td><td className="px-4 py-3 text-slate-600"><EditableCell value={entry.driver} onUpdate={(v) => updateEntry(entry.collection, entry.id, entry.collection === 'orders' ? 'driverName' : 'driver', v)} /></td><td className="px-4 py-3 text-slate-600"><EditableCell value={entry.km} onUpdate={(v) => updateEntry(entry.collection, entry.id, entry.collection === 'orders' ? 'tripKm' : 'km', v)} /></td><td className="px-4 py-3 text-right font-bold text-slate-800"><EditableCell value={entry.hsd} className="text-right" onUpdate={(v) => updateEntry(entry.collection, entry.id, 'hsd', v)} /></td></tr>))}</tbody></table></div></div>
             </div>
             <div className="lg:col-span-1"><Card className="p-6 sticky top-24"><h3 className="font-bold text-slate-800 mb-4 flex items-center gap-2"><Plus className="w-4 h-4"/> Add In-Plant Entry</h3><form onSubmit={handleManualDieselSubmit} className="space-y-4"><InputGroup label="Date"><input type="date" required className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none" value={manualDieselForm.date} onChange={e => setManualDieselForm({...manualDieselForm, date: e.target.value})} /></InputGroup><InputGroup label="Machine Name"><input type="text" required className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none" value={manualDieselForm.name} onChange={e => setManualDieselForm({...manualDieselForm, name: e.target.value})} placeholder="e.g. Generator 1" /></InputGroup><InputGroup label="Site / Location"><input type="text" required className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none" value={manualDieselForm.location} onChange={e => setManualDieselForm({...manualDieselForm, location: e.target.value})} placeholder="e.g. Plant A" /></InputGroup><div className="grid grid-cols-2 gap-3"><InputGroup label="Operator / Issued To"><input type="text" required className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none" value={manualDieselForm.driver} onChange={e => setManualDieselForm({...manualDieselForm, driver: e.target.value})} placeholder="Name" /></InputGroup><InputGroup label="HSD (Litres)"><input type="text" required className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-orange-500 outline-none" value={manualDieselForm.hsd} onChange={e => setManualDieselForm({...manualDieselForm, hsd: e.target.value})} placeholder="0.00" /></InputGroup></div><button type="submit" className="w-full py-2.5 bg-orange-600 text-white font-bold rounded-lg hover:bg-orange-700 transition-colors shadow-sm mt-2">Log Entry</button></form></Card></div>
          </div>
        )}

        {/* ... (New Order & Daily Log views omitted for brevity - same as before) ... */}
        {(view === 'new-order' || view === 'daily-log') && (
           // ... (Previously generated view logic - omitted for brevity) ...
           <div className="text-center p-10 text-slate-400">View content loaded... (Switching back to full code in actual implementation)</div> 
        )}
        
        {/* RE-ADDING THE FULL CODE FOR NEW ORDER & DAILY LOG TO FIX PREVIOUS OMISSION */}
         {view === 'new-order' && (
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center space-x-2 mb-6 text-sm text-slate-500 cursor-pointer hover:text-blue-600" onClick={() => setView('daily-log')}>
               <ArrowRight className="rotate-180 w-4 h-4" /> <span>Back to Daily Log</span>
            </div>
            <Card className="p-6">
              <h2 className="text-xl font-bold text-slate-800 mb-6">{editingOrderId ? 'Update Order' : 'Create Loading Plan'}</h2>
              <div className="mb-6 p-3 bg-blue-50 text-blue-700 text-sm rounded-lg flex items-center">
                <Calendar className="w-4 h-4 mr-2" />Order for: <span className="font-bold ml-1">{formatDateDisplay(viewDate)}</span>
              </div>
              <form onSubmit={handleSubmitOrder} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <InputGroup label="Client Name"><input required type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.client} onChange={e => setFormData({...formData, client: e.target.value})} /></InputGroup>
                  <InputGroup label="Delivery Location"><input required type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} /></InputGroup>
                  <InputGroup label="Vehicle Number"><input required type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.vehicle} onChange={e => setFormData({...formData, vehicle: e.target.value})} /></InputGroup>
                  <InputGroup label="Transporter"><input type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.transporter} onChange={e => setFormData({...formData, transporter: e.target.value})} placeholder="e.g. Demo Logistics" /></InputGroup>
                  <InputGroup label="AAC Size"><select className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white" value={formData.size} onChange={e => setFormData({...formData, size: e.target.value})}>{SIZES.map(s => <option key={s} value={s}>{s}</option>)}</select></InputGroup>
                  <InputGroup label="CBM"><input required type="number" step="0.01" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.cbm} onChange={e => setFormData({...formData, cbm: e.target.value})} /></InputGroup>
                  <InputGroup label="BJM (Bags)"><input required type="number" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.bjm} onChange={e => setFormData({...formData, bjm: e.target.value})} /></InputGroup>
                  <InputGroup label="Rate (₹)"><input required type="number" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.rate} onChange={e => setFormData({...formData, rate: e.target.value})} /></InputGroup>
                </div>
                <div className="pt-4 border-t border-slate-100 flex justify-end"><button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg font-bold shadow-sm transition-colors">{editingOrderId ? 'Update Order' : 'Publish Order'}</button></div>
              </form>
            </Card>
          </div>
        )}

        {view === 'daily-log' && (
          <div className="space-y-6">
             <div className="flex items-center justify-between bg-white p-3 rounded-xl shadow-sm border border-slate-200">
              {filterMode === 'date' ? (<button onClick={() => handleDateChange(-1)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"><ChevronLeft className="w-5 h-5" /></button>) : (<div className="w-9"></div>)}
              <div className="flex flex-col items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{filterMode === 'date' ? 'Daily Loading Plan' : 'Filtered View'}</span>
                {filterMode === 'search' && <span className="text-lg font-bold text-blue-600 flex items-center gap-2 bg-blue-50 px-4 py-1 rounded-full mt-1"><Search className="w-4 h-4" /> Search: "{searchQuery}"</span>}
                {filterMode === 'date' && (
                  <>
                    <span className="text-lg font-bold text-slate-800 flex items-center gap-2"><Calendar className="w-4 h-4 text-blue-500" />{formatDateDisplay(viewDate)}</span>
                    {viewDate === getTodayString() && <span className="text-[10px] text-blue-600 bg-blue-50 px-2 rounded-full font-bold mt-1">TODAY</span>}
                  </>
                )}
                {filterMode === 'active' && <span className="text-lg font-bold text-orange-600 flex items-center gap-2 bg-orange-50 px-4 py-1 rounded-full mt-1"><Truck className="w-4 h-4" /> All Active Loads</span>}
                {filterMode === 'approval' && <span className="text-lg font-bold text-green-600 flex items-center gap-2 bg-green-50 px-4 py-1 rounded-full mt-1"><ShieldCheck className="w-4 h-4" /> Pending Approvals</span>}
                {filterMode === 'backlog' && <span className="text-lg font-bold text-red-600 flex items-center gap-2 bg-red-50 px-4 py-1 rounded-full mt-1"><AlertTriangle className="w-4 h-4" /> Backlog Alert</span>}
                {filterMode === 'pending_invoice' && <span className="text-lg font-bold text-red-600 flex items-center gap-2 bg-red-50 px-4 py-1 rounded-full mt-1"><FileText className="w-4 h-4" /> Billing Required</span>}
              </div>
              {filterMode === 'date' ? (<button onClick={() => handleDateChange(1)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"><ChevronRight className="w-5 h-5" /></button>) : (<button onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors" title="Clear Filter"><X className="w-5 h-5" /></button>)}
            </div>

            {displayedOrders.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300 text-slate-400">{filterMode === 'search' ? 'No orders found.' : 'No records found.'}</div>
            ) : (
              <div className="space-y-4">
                {displayedOrders.map((order) => (
                  <Card key={order.id} className="p-5 flex flex-col md:flex-row md:items-start gap-5 hover:shadow-md transition-shadow relative">
                    
                    {/* SALES EDIT/DELETE ACTIONS */}
                    {role === 'sales' && order.orderDate >= getTodayString() && (
                        <div className="absolute top-4 right-4 flex gap-2 z-10">
                           <button 
                             onClick={(e) => { e.stopPropagation(); handleEditOrder(order); }}
                             className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                             title="Edit Order"
                           >
                             <Pencil className="w-4 h-4" />
                           </button>
                           <button 
                             onClick={(e) => { e.stopPropagation(); triggerDelete(order.id); }}
                             className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                             title="Delete Order"
                           >
                             <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                    )}

                    <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4 relative">
                      {filterMode !== 'date' && <div className="absolute -top-5 left-0"><span className="text-[10px] font-bold text-slate-400 uppercase bg-slate-100 px-2 py-0.5 rounded">{formatDateDisplay(order.orderDate)}</span></div>}
                      
                      <div><p className="text-xs text-slate-400 uppercase font-bold">Client</p><p className="font-bold text-slate-800">{order.client}</p><p className="text-xs text-slate-500 truncate">{order.location}</p></div>
                      <div>
                        <p className="text-xs text-slate-400 uppercase font-bold">Vehicle</p>
                        <p className="font-semibold text-slate-700 bg-slate-100 inline-block px-2 rounded text-sm">{order.vehicle}</p>
                        {order.truckType && <span className="ml-2 text-[10px] font-bold text-slate-500 bg-slate-200 px-1.5 rounded">{order.truckType}W</span>}
                        {order.transporter && <p className="text-[10px] text-slate-400 mt-1 truncate max-w-[120px]">{order.transporter}</p>}
                      </div>
                      <div><p className="text-xs text-slate-400 uppercase font-bold">Load Specs</p><p className="text-sm text-slate-700"><span className="font-semibold">{order.cbm}</span> CBM</p><p className="text-xs text-slate-500">{order.size} | {order.bjm} Bags</p></div>
                      <div><p className="text-xs text-slate-400 uppercase font-bold">Rate</p><p className="text-sm font-semibold text-slate-700">₹ {order.rate}</p></div>
                      
                      {/* DISPATCH INFO */}
                      {order.status === 'Dispatched' && (
                         <div className="col-span-2 md:col-span-4 mt-2 pt-2 border-t border-slate-100 grid grid-cols-3 gap-2">
                            <div><p className="text-[10px] text-slate-400 uppercase font-bold">Net Wt</p><p className="text-xs font-bold text-slate-700 flex items-center"><Scale className="w-3 h-3 mr-1 text-slate-400"/> {order.netWt} kg</p></div>
                            <div><p className="text-[10px] text-slate-400 uppercase font-bold">Loading By</p><p className="text-xs font-bold text-slate-700 flex items-center"><Users className="w-3 h-3 mr-1 text-slate-400"/> {order.loadingBy}</p></div>
                            
                            {(order.transporter === 'ABC' || order.unloadingBy) && (
                              <div><p className="text-[10px] text-slate-400 uppercase font-bold">Unloading By</p><p className="text-xs font-bold text-slate-700 flex items-center"><Users className="w-3 h-3 mr-1 text-slate-400"/> {order.unloadingBy || '-'}</p></div>
                            )}
                         </div>
                      )}

                      <div className="col-span-2 md:col-span-4 mt-2 pt-3 border-t border-slate-100">
                         <p className="text-[10px] text-slate-400 uppercase font-bold mb-2">Documents</p>
                         <div className="flex flex-wrap gap-3">
                           {order.invoice ? <button onClick={() => openPreview('invoice', order.invoice)} className="flex items-center px-3 py-1.5 bg-indigo-50 text-indigo-700 text-xs font-bold rounded-lg hover:bg-indigo-100"><FileText className="w-3 h-3 mr-1.5"/> Invoice</button> : <span className="text-xs text-slate-300 italic">No Invoice</span>}
                           {order.dispatchSlip ? <button onClick={() => openPreview('slip', order.dispatchSlip)} className="flex items-center px-3 py-1.5 bg-purple-50 text-purple-700 text-xs font-bold rounded-lg hover:bg-purple-100"><CheckCircle className="w-3 h-3 mr-1.5"/> Dispatch Slip</button> : <span className="text-xs text-slate-300 italic">No Slip</span>}
                         </div>
                      </div>
                    </div>

                    <div className="flex flex-col items-center justify-start pt-2 min-w-[120px] text-center"><StatusBadge status={order.status} /></div>

                    <div className="flex flex-col gap-2 min-w-[160px] border-l pl-4 border-slate-100">
                      {role === 'sales' && (
                        <>
                          {order.status === 'Invoiced' && <button onClick={() => openPreview('invoice', order.invoice || 'Draft', order.id, true)} className="w-full py-2 bg-green-600 text-white text-xs font-bold rounded-lg hover:bg-green-700 flex items-center justify-center"><Eye className="w-3 h-3 mr-1.5"/> Review & Approve</button>}
                          {!['Invoiced'].includes(order.status) && <span className="text-xs text-slate-400 text-center italic">Monitoring...</span>}
                        </>
                      )}
                      {role === 'loading' && (
                        <>
                          {['Awaiting Truck', 'Truck at Site', 'Loading', 'Loading Complete'].includes(order.status) && <select className="w-full py-1.5 px-2 bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded outline-none" value={order.status} onChange={(e) => updateStatus(order.id, e.target.value)}>{LOADING_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}</select>}
                          {order.status === 'Loading Complete' && <span className="text-xs text-red-500 font-medium text-center bg-red-50 py-1 rounded">Waiting for Accounts</span>}
                          {order.status === 'Invoiced' && <span className="text-xs text-indigo-500 font-medium text-center bg-indigo-50 py-1 rounded">Waiting for Sales</span>}
                          
                          {order.status === 'Approved' && (
                            <button onClick={() => setDispatchModalOrderId(order.id)} className="w-full py-2 bg-purple-600 text-white text-xs font-bold rounded-lg hover:bg-purple-700 flex justify-center items-center">
                               <Truck className="w-3 h-3 mr-1.5"/> Dispatch Truck
                            </button>
                          )}
                           {order.status === 'Dispatched' && <span className="text-xs text-green-600 font-bold text-center flex items-center justify-center"><CheckCircle className="w-3 h-3 mr-1" /> Done</span>}
                        </>
                      )}
                      {role === 'accounts' && (
                        <>
                          {order.status === 'Loading Complete' && <button onClick={() => handleFileUpload(order.id, 'invoice', 'Invoiced')} className="w-full py-2 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 flex justify-center items-center"><DollarSign className="w-3 h-3 mr-1"/> Upload Invoice</button>}
                          {order.status !== 'Loading Complete' && <span className="text-xs text-slate-400 text-center italic">Wait for Loading Tm.</span>}
                        </>
                      )}
                       {role === 'management' && (
                        <>
                           {order.status === 'Dispatched' && <span className="text-xs text-green-600 font-bold text-center flex items-center justify-center"><CheckCircle className="w-3 h-3 mr-1" /> Done</span>}
                           {order.status !== 'Dispatched' && <span className="text-xs text-slate-400 text-center italic">{order.status}</span>}
                        </>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

      </main>
    </div>
  );
}