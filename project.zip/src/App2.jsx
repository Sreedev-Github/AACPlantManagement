import React, { useState } from 'react';
import { 
  Package, Truck, FileText, LogOut, Plus, DollarSign, Briefcase, Calendar, BarChart3, 
  Search, ChevronLeft, ChevronRight, X, AlertTriangle, CheckCircle, Eye, Pencil, Trash2,
  ArrowRight, LayoutGrid, FileSpreadsheet, Fuel, ClipboardList, ScrollText, 
  Layers, Boxes, Download, Factory, AlertCircle, ShieldCheck, Users, Scale
} from 'lucide-react';
import { AppProvider, useApp } from './context/AppContext';
import { Card, StatCard, InputGroup, StatusBadge } from './components/ui/UIComponents';
import { ConfirmModal } from './components/modals/ConfirmModal';
import { ImportModal } from './components/modals/ImportModal';
import { initializeTestData } from './utils/localStorage';
import { 
  getTodayString, 
  formatDateDisplay, 
  formatDateTimeDisplay,
  safeNum,
  safeInt,
  getPreviousDateString,
  calculateColumnTotal
} from './utils/helpers';
import { 
  SIZES, 
  LOADING_STATUSES, 
  RATE_CARD, 
  GS_SURCHARGE,
  RAW_MATERIALS_LIST,
  FINISHED_STOCK_SIZES 
} from './utils/constants';
import './index.css';

// Modals
const DocPreviewModal = ({ fileType, fileName, canApprove, onClose, onApprove, orderData }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4 backdrop-blur-sm">
    <div className="bg-white rounded-xl shadow-2xl max-w-3xl w-full p-6">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-bold text-lg">{fileType === 'slip' ? 'Dispatch Slip' : 'Tax Invoice'}</h3>
        <button onClick={onClose}><X className="w-5 h-5 text-slate-400"/></button>
      </div>
      <div className="bg-slate-100 rounded-lg p-6 text-center mb-4">
        <FileText className="w-16 h-16 mx-auto text-slate-400 mb-2"/>
        <p className="text-sm font-mono">{fileName}</p>
        <p className="text-xs text-slate-400 mt-1">Preview not available in local mode</p>
      </div>
      {orderData && (
        <div className="bg-blue-50 p-4 rounded-lg mb-4">
          <h4 className="font-bold text-sm mb-2">Order Details:</h4>
          <div className="grid grid-cols-2 gap-2 text-xs">
            <div><span className="text-blue-600">Client:</span> {orderData.client}</div>
            <div><span className="text-blue-600">Vehicle:</span> {orderData.vehicle}</div>
            <div><span className="text-blue-600">CBM:</span> {orderData.cbm}</div>
            <div><span className="text-blue-600">Rate:</span> ₹{orderData.rate}</div>
          </div>
        </div>
      )}
      <div className="flex justify-end gap-3">
        <button onClick={onClose} className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-lg">Close</button>
        {canApprove && <button onClick={onApprove} className="px-4 py-2 bg-green-600 text-white font-bold rounded-lg hover:bg-green-700">Approve</button>}
      </div>
    </div>
  </div>
);

const DispatchModal = ({ order, onClose, onSubmit }) => {
  const [formData, setFormData] = useState({
    netWt: order.netWt || '',
    grossWeight: order.grossWeight || '',
    tareWeight: order.tareWeight || '',
    loadingBy: order.loadingBy || '',
    unloadingBy: order.unloadingBy || '',
    driverName: order.driverName || '',
    tripKm: order.tripKm || '',
    hsd: order.hsd || ''
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-4">
          <h3 className="font-bold text-lg flex items-center gap-2"><Truck className="w-5 h-5"/> Dispatch Truck</h3>
          <button onClick={onClose}><X className="w-5 h-5"/></button>
        </div>
        <div className="bg-purple-50 p-4 rounded-lg mb-4">
          <p className="font-bold">{order.client}</p>
          <p className="text-sm text-purple-600">{order.vehicle} • {order.cbm} CBM</p>
        </div>
        <form onSubmit={(e) => { e.preventDefault(); onSubmit(order.id, formData); }} className="space-y-4">
          <div className="grid grid-cols-3 gap-4">
            <InputGroup label="Net Wt (kg)">
              <input type="number" step="0.001" required className="w-full p-2 border rounded-lg" value={formData.netWt} onChange={e => setFormData({...formData, netWt: e.target.value})} />
            </InputGroup>
            <InputGroup label="Gross Wt (kg)">
              <input type="number" step="0.001" className="w-full p-2 border rounded-lg" value={formData.grossWeight} onChange={e => setFormData({...formData, grossWeight: e.target.value})} />
            </InputGroup>
            <InputGroup label="Tare Wt (kg)">
              <input type="number" step="0.001" className="w-full p-2 border rounded-lg" value={formData.tareWeight} onChange={e => setFormData({...formData, tareWeight: e.target.value})} />
            </InputGroup>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <InputGroup label="Loading By">
              <input type="text" required className="w-full p-2 border rounded-lg" value={formData.loadingBy} onChange={e => setFormData({...formData, loadingBy: e.target.value})} />
            </InputGroup>
            <InputGroup label="Unloading By">
              <input type="text" className="w-full p-2 border rounded-lg" value={formData.unloadingBy} onChange={e => setFormData({...formData, unloadingBy: e.target.value})} />
            </InputGroup>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <InputGroup label="Driver Name">
              <input type="text" className="w-full p-2 border rounded-lg" value={formData.driverName} onChange={e => setFormData({...formData, driverName: e.target.value})} />
            </InputGroup>
            <InputGroup label="Trip KM">
              <input type="number" className="w-full p-2 border rounded-lg" value={formData.tripKm} onChange={e => setFormData({...formData, tripKm: e.target.value})} />
            </InputGroup>
            <InputGroup label="HSD (Litres)">
              <input type="number" className="w-full p-2 border rounded-lg" value={formData.hsd} onChange={e => setFormData({...formData, hsd: e.target.value})} />
            </InputGroup>
          </div>
          <div className="flex justify-end gap-3 pt-4">
            <button type="button" onClick={onClose} className="px-4 py-2 text-slate-600 font-bold hover:bg-slate-100 rounded-lg">Cancel</button>
            <button type="submit" className="px-4 py-2 bg-purple-600 text-white font-bold rounded-lg hover:bg-purple-700">Dispatch</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const RoleSelection = ({ onRoleSelect }) => (
  <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
    <div className="max-w-md w-full bg-white rounded-2xl shadow-lg p-8 space-y-6">
      <div className="text-center">
        <div className="bg-blue-600 w-16 h-16 rounded-2xl mx-auto flex items-center justify-center mb-4 shadow-blue-200 shadow-xl">
          <Package className="text-white w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold text-slate-900">AAC Plant Manager</h1>
        <p className="text-slate-500 mt-2">Select your department</p>
      </div>
      <div className="grid gap-3">
        <button onClick={() => onRoleSelect('sales')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-blue-500 hover:bg-blue-50 transition-all group">
          <div className="bg-blue-100 p-2 rounded-lg"><Briefcase className="text-blue-600 w-5 h-5" /></div>
          <div className="ml-4 text-left"><p className="font-bold text-slate-700">Sales Team</p></div>
        </button>
        <button onClick={() => onRoleSelect('loading')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-orange-500 hover:bg-orange-50 transition-all group">
          <div className="bg-orange-100 p-2 rounded-lg"><Truck className="text-orange-600 w-5 h-5" /></div>
          <div className="ml-4 text-left"><p className="font-bold text-slate-700">Loading Team</p></div>
        </button>
        <button onClick={() => onRoleSelect('production')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-cyan-500 hover:bg-cyan-50 transition-all group">
          <div className="bg-cyan-100 p-2 rounded-lg"><Calendar className="text-cyan-600 w-5 h-5" /></div>
          <div className="ml-4 text-left"><p className="font-bold text-slate-700">Production Team</p></div>
        </button>
        <button onClick={() => onRoleSelect('accounts')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-green-500 hover:bg-green-50 transition-all group">
          <div className="bg-green-100 p-2 rounded-lg"><DollarSign className="text-green-600 w-5 h-5" /></div>
          <div className="ml-4 text-left"><p className="font-bold text-slate-700">Accounts</p></div>
        </button>
        <button onClick={() => onRoleSelect('management')} className="flex items-center p-4 border-2 border-slate-100 rounded-xl hover:border-purple-500 hover:bg-purple-50 transition-all group">
          <div className="bg-purple-100 p-2 rounded-lg"><BarChart3 className="text-purple-600 w-5 h-5" /></div>
          <div className="ml-4 text-left"><p className="font-bold text-slate-700">Management</p></div>
        </button>
      </div>
    </div>
  </div>
);

const Dashboard = () => {
  const { role, setRole, orders, dieselEntries, logs, rawStock, finishedStock,
          showToast, logAction, addOrder, updateOrder, deleteOrder, addDieselEntry,
          updateRawStockForDate, updateFinishedStockForDate, loadAllData, appMsg } = useApp();
  
  const [view, setView] = useState('home');
  const [viewDate, setViewDate] = useState(getTodayString());
  const [searchQuery, setSearchQuery] = useState('');
  const [filterMode, setFilterMode] = useState('date');
  
  // Form state
  const [formData, setFormData] = useState({
    client: '', location: '', vehicle: '', transporter: '',
    size: SIZES[3], cbm: '', bjm: '', rate: '', bjmRate: ''
  });
  const [editingOrderId, setEditingOrderId] = useState(null);
  
  // Modal state
  const [showImportModal, setShowImportModal] = useState(false);
  const [deleteConfirmId, setDeleteConfirmId] = useState(null);
  const [previewFile, setPreviewFile] = useState(null);
  const [dispatchModalOrderId, setDispatchModalOrderId] = useState(null);

  const handleTestData = () => {
    initializeTestData();
    loadAllData();
    showToast('Test data generated!');
    logAction('TEST DATA', 'Generated test data');
  };

  const handleSearch = (e) => {
    const val = e.target.value;
    setSearchQuery(val);
    if (val) {
      setFilterMode('search');
      if (view !== 'daily-log') setView('daily-log');
    } else {
      setFilterMode('date');
    }
  };

  const handleDateChange = (days) => {
    const parts = viewDate.split('-');
    const date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12, 0, 0));
    date.setDate(date.getDate() + days);
    setViewDate(date.toISOString().split('T')[0]);
    setSearchQuery('');
    setFilterMode('date');
  };

  const handleEditOrder = (order) => {
    setEditingOrderId(order.id);
    setFormData({
      client: order.client,
      location: order.location,
      vehicle: order.vehicle,
      transporter: order.transporter || '',
      size: order.size,
      cbm: order.cbm,
      bjm: order.bjm,
      rate: order.rate,
      bjmRate: order.bjmRate || ''
    });
    setView('new-order');
  };

  const triggerDelete = (orderId) => {
    setDeleteConfirmId(orderId);
  };

  const confirmDeleteOrder = () => {
    if (!deleteConfirmId) return;
    deleteOrder(deleteConfirmId);
    logAction('DELETE ORDER', `Deleted Order ID: ${deleteConfirmId}`);
    showToast("Order deleted");
    setDeleteConfirmId(null);
  };

  const handleSubmitOrder = (e) => {
    e.preventDefault();
    
    if (editingOrderId) {
      updateOrder(editingOrderId, {
        ...formData,
        cbm: Number(formData.cbm),
        bjm: Number(formData.bjm),
        rate: Number(formData.rate),
        bjmRate: Number(formData.bjmRate)
      });
      logAction('UPDATE ORDER', `Updated order for ${formData.client}`);
      showToast("Order Updated");
      setEditingOrderId(null);
    } else {
      addOrder({
        ...formData,
        cbm: Number(formData.cbm),
        bjm: Number(formData.bjm),
        rate: Number(formData.rate),
        bjmRate: Number(formData.bjmRate),
        status: 'Awaiting Truck',
        orderDate: viewDate,
        dispatchSlip: null,
        invoice: null,
        truckType: null,
        netWt: null,
        loadingBy: null,
        unloadingBy: null,
        hsd: null,
        loadingRate: 0,
        unloadingRate: 0,
        remarks: '',
        gsChecked: false
      });
      logAction('CREATE ORDER', `Created order for ${formData.client}`);
      showToast(`Order Created`);
    }
    
    setView('daily-log');
    setFilterMode('date');
    setSearchQuery('');
    setFormData({
      client: '', location: '', vehicle: '', transporter: '',
      size: SIZES[3], cbm: '', bjm: '', rate: '', bjmRate: ''
    });
  };

  const handleBulkImport = (data) => {
    let count = 0;
    for (const item of data) {
      addOrder(item);
      count++;
    }
    logAction('BULK IMPORT', `Imported ${count} records from CSV`);
    showToast(`Successfully imported ${count} records`);
    setShowImportModal(false);
  };

  const updateStatus = (orderId, newStatus, extraData = {}) => {
    updateOrder(orderId, { status: newStatus, ...extraData });
    logAction('STATUS CHANGE', `Updated Order ${orderId} to ${newStatus}`);
    showToast(`Status updated`);
  };

  const handleFileUpload = (orderId, type, nextStatus) => {
    const fileName = type === 'dispatchSlip' 
      ? `Slip_${Math.floor(Math.random()*1000)}.jpg` 
      : `Invoice_${Math.floor(Math.random()*1000)}.pdf`;
    updateStatus(orderId, nextStatus, { [type]: fileName });
    logAction('FILE UPLOAD', `Uploaded ${type} for Order ${orderId}`);
  };

  const openPreview = (fileType, fileName, orderId = null, canApprove = false) => {
    const orderData = orders.find(o => o.id === orderId);
    setPreviewFile({ fileType, fileName, orderId, canApprove, orderData });
  };

  const handleApproveFromPreview = () => {
    if (previewFile && previewFile.orderId) {
      updateStatus(previewFile.orderId, 'Approved');
      setPreviewFile(null);
    }
  };

  const handleDispatchSubmit = (orderId, data) => {
    const slipName = `DS-${orderId.substring(0, 4)}-${Math.floor(Math.random()*1000)}.pdf`;
    updateStatus(orderId, 'Dispatched', { ...data, dispatchSlip: slipName });
    logAction('DISPATCH', `Dispatched Order ${orderId} with slip ${slipName}`);
    setDispatchModalOrderId(null);
  };

  const getStats = () => {
    const todayStr = getTodayString();
    const active = orders.filter(o => ['Loading', 'Truck at Site', 'Loading Complete'].includes(o.status)).length;
    const pendingInv = orders.filter(o => o.status === 'Loading Complete').length;
    const pendingApprove = orders.filter(o => o.status === 'Invoiced').length;
    const todayOrders = orders.filter(o => o.orderDate === todayStr).length;
    const backlog = orders.filter(o => o.orderDate < todayStr && o.status !== 'Dispatched').length;
    return { active, pendingInv, pendingApprove, todayOrders, backlog };
  };

  const stats = getStats();

  let displayedOrders = [];
  if (filterMode === 'search') {
    const lowerQ = searchQuery.toLowerCase();
    displayedOrders = orders.filter(o => 
      o.client.toLowerCase().includes(lowerQ) || o.vehicle.toLowerCase().includes(lowerQ)
    );
  } else if (filterMode === 'date') {
    displayedOrders = orders.filter(o => o.orderDate === viewDate);
  } else if (filterMode === 'active') {
    displayedOrders = orders.filter(o => ['Loading', 'Truck at Site', 'Loading Complete'].includes(o.status));
  } else if (filterMode === 'approval') {
    displayedOrders = orders.filter(o => o.status === 'Invoiced');
  } else if (filterMode === 'backlog') {
    const todayStr = getTodayString();
    displayedOrders = orders.filter(o => o.orderDate < todayStr && o.status !== 'Dispatched');
  } else if (filterMode === 'pending_invoice') {
    displayedOrders = orders.filter(o => o.status === 'Loading Complete');
  }

  const setViewAndFilter = (viewName, mode, date = null) => {
    setSearchQuery('');
    setView(viewName);
    setFilterMode(mode);
    if (date) setViewDate(date);
  };

  const dispatchOrderObj = orders.find(o => o.id === dispatchModalOrderId);

  return (
    <div className="min-h-screen bg-slate-50 pb-20 relative">
      {appMsg && (
        <div className="fixed top-4 left-1/2 transform -translate-x-1/2 z-50 bg-slate-800 text-white px-4 py-2 rounded-full shadow-lg text-sm font-bold animate-bounce">
          {appMsg}
        </div>
      )}
      
      {previewFile && (
        <DocPreviewModal 
          fileType={previewFile.fileType}
          fileName={previewFile.fileName}
          canApprove={previewFile.canApprove}
          onClose={() => setPreviewFile(null)}
          onApprove={handleApproveFromPreview}
          orderData={previewFile.orderData}
        />
      )}
      
      {deleteConfirmId && (
        <ConfirmModal 
          title="Delete Order?"
          message="This action cannot be undone. Are you sure?"
          onConfirm={confirmDeleteOrder}
          onCancel={() => setDeleteConfirmId(null)}
        />
      )}
      
      {showImportModal && (
        <ImportModal 
          onClose={() => setShowImportModal(false)}
          onImport={handleBulkImport}
        />
      )}
      
      {dispatchOrderObj && (
        <DispatchModal 
          order={dispatchOrderObj}
          onClose={() => setDispatchModalOrderId(null)}
          onSubmit={handleDispatchSubmit}
        />
      )}

      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-10">
        <div className="max-w-5xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center space-x-2 cursor-pointer shrink-0" onClick={() => setViewAndFilter('home', 'date')}>
            <div className="bg-blue-600 p-1.5 rounded-lg"><Package className="text-white w-4 h-4" /></div>
            <span className="font-bold text-slate-800 hidden md:block">AAC Manager</span>
            <span className="px-2 py-0.5 rounded bg-slate-100 text-slate-500 text-xs font-medium uppercase border border-slate-200">{role}</span>
          </div>
          <div className="flex-1 max-w-md mx-4 relative">
            <input 
              type="text" 
              placeholder="Search..." 
              className="w-full bg-slate-100 border border-slate-200 rounded-lg py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500 transition-all" 
              value={searchQuery} 
              onChange={handleSearch} 
            />
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          </div>
          <div className="flex items-center space-x-2 shrink-0">
            <button onClick={handleTestData} className="text-slate-400 hover:text-blue-600 p-2" title="Generate Test Data">
              <Plus className="w-5 h-5" />
            </button>
            {role === 'sales' && view === 'daily-log' && filterMode === 'date' && viewDate >= getTodayString() && (
              <button 
                onClick={() => {
                  setEditingOrderId(null);
                  setFormData({
                    client: '', location: '', vehicle: '', transporter: '',
                    size: SIZES[3], cbm: '', bjm: '', rate: '', bjmRate: ''
                  });
                  setView('new-order');
                }} 
                className="bg-blue-600 hover:bg-blue-700 text-white px-3 py-2 rounded-lg text-sm font-medium flex items-center shadow-sm whitespace-nowrap"
              >
                <Plus className="w-4 h-4 md:mr-1.5" /> <span className="hidden md:inline">New Order</span>
              </button>
            )}
            <button onClick={() => setRole(null)} className="text-slate-400 hover:text-red-500 p-2">
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 py-6">
        {/* HOME VIEW */}
        {view === 'home' && (
          <div className="space-y-8">
            <div>
              <h2 className="text-2xl font-bold text-slate-800">Welcome back, {role.toUpperCase()}</h2>
              <p className="text-slate-500">Activity Overview</p>
            </div>

            {/* Sales Dashboard */}
            {role === 'sales' && (
              <>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Orders" value={stats.todayOrders} icon={Calendar} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'active')} label="Active Loads" value={stats.active} icon={Truck} colorClass="bg-orange-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'approval')} label="Inv. To Approve" value={stats.pendingApprove} icon={ShieldCheck} colorClass="bg-green-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'backlog')} label="Backlog" value={stats.backlog} icon={AlertTriangle} colorClass="bg-red-500" />
                </div>
                <div className="grid md:grid-cols-2 gap-4 mt-8">
                  <Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer">
                    <div><div className="flex items-center mb-2"><LayoutGrid className="w-5 h-5 text-blue-600 mr-2"/><span className="font-bold text-lg">Daily Loading Plan</span></div><p className="text-sm text-slate-500">Manage schedules & invoices.</p></div><ArrowRight className="text-slate-300 group-hover:text-blue-600"/>
                  </Card>
                </div>
              </>
            )}

            {/* Loading Dashboard */}
            {role === 'loading' && (
              <>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Orders" value={stats.todayOrders} icon={Calendar} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'active')} label="Active Loads" value={stats.active} icon={Truck} colorClass="bg-orange-500" />
                </div>
                <div className="grid md:grid-cols-1 gap-4 mt-8">
                  <Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer">
                    <div><div className="flex items-center mb-2"><LayoutGrid className="w-5 h-5 text-orange-600 mr-2"/><span className="font-bold text-lg">Daily Loading Log</span></div><p className="text-sm text-slate-500">Update truck status & dispatch.</p></div><ArrowRight className="text-slate-300 group-hover:text-orange-600"/>
                  </Card>
                </div>
              </>
            )}

            {/* Production Dashboard */}
            {role === 'production' && (
              <div className="grid md:grid-cols-2 gap-4">
                <Card onClick={() => setView('production-dashboard')} className="p-6 flex items-center justify-between group cursor-pointer">
                  <div><div className="flex items-center mb-2"><Layers className="w-5 h-5 text-cyan-600 mr-2"/><span className="font-bold text-lg">Raw Material Stock</span></div><p className="text-sm text-slate-500">Manage raw material inventory.</p></div><ArrowRight className="text-slate-300 group-hover:text-cyan-600"/>
                </Card>
                <Card onClick={() => setView('production-dashboard')} className="p-6 flex items-center justify-between group cursor-pointer">
                  <div><div className="flex items-center mb-2"><Boxes className="w-5 h-5 text-indigo-600 mr-2"/><span className="font-bold text-lg">Daily Production Report</span></div><p className="text-sm text-slate-500">Track finished goods & daily output.</p></div><ArrowRight className="text-slate-300 group-hover:text-indigo-600"/>
                </Card>
              </div>
            )}

            {/* Accounts Dashboard */}
            {role === 'accounts' && (
              <>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Orders" value={stats.todayOrders} icon={Calendar} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'pending_invoice')} label="Pending Invoices" value={stats.pendingInv} icon={FileText} colorClass="bg-red-500" />
                </div>
                <div className="grid md:grid-cols-1 gap-4 mt-8">
                  <Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer">
                    <div><div className="flex items-center mb-2"><LayoutGrid className="w-5 h-5 text-green-600 mr-2"/><span className="font-bold text-lg">Loading & Billing</span></div><p className="text-sm text-slate-500">Upload tax invoices.</p></div><ArrowRight className="text-slate-300 group-hover:text-green-600"/>
                  </Card>
                </div>
              </>
            )}

            {/* Management Dashboard */}
            {role === 'management' && (
              <>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} label="Today's Activity" value={stats.todayOrders} icon={Calendar} colorClass="bg-purple-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'active')} label="Active Trucks" value={stats.active} icon={Truck} colorClass="bg-blue-500" />
                  <StatCard onClick={() => setViewAndFilter('daily-log', 'pending_invoice')} label="Billing Pending" value={stats.pendingInv} icon={AlertCircle} colorClass="bg-red-500" />
                </div>
                <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4 mt-8">
                  <Card onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-6 flex items-center justify-between group cursor-pointer">
                    <div><div className="flex items-center mb-2"><BarChart3 className="w-5 h-5 text-purple-600 mr-2"/><span className="font-bold text-lg">Daily Activity</span></div><p className="text-sm text-slate-500">View all dispatch records.</p></div><ArrowRight className="text-slate-300 group-hover:text-purple-600"/>
                  </Card>
                  <Card onClick={() => setView('production-dashboard')} className="p-6 flex items-center justify-between group cursor-pointer">
                    <div><div className="flex items-center mb-2"><Factory className="w-5 h-5 text-cyan-600 mr-2"/><span className="font-bold text-lg">Production Stock</span></div><p className="text-sm text-slate-500">Raw Material & Inventory.</p></div><ArrowRight className="text-slate-300 group-hover:text-cyan-600"/>
                  </Card>
                  <Card onClick={() => setView('system-logs')} className="p-6 flex items-center justify-between group cursor-pointer">
                    <div><div className="flex items-center mb-2"><ScrollText className="w-5 h-5 text-slate-600 mr-2"/><span className="font-bold text-lg">System Logs</span></div><p className="text-sm text-slate-500">Audit trail of changes.</p></div><ArrowRight className="text-slate-300 group-hover:text-slate-600"/>
                  </Card>
                </div>
              </>
            )}
          </div>
        )}

        {/* NEW ORDER VIEW */}
        {view === 'new-order' && (
          <div className="max-w-2xl mx-auto">
            <div className="flex items-center space-x-2 mb-6 text-sm text-slate-500 cursor-pointer hover:text-blue-600" onClick={() => setView('daily-log')}>
              <ArrowRight className="rotate-180 w-4 h-4" /> <span>Back to Daily Log</span>
            </div>
            <Card className="p-6">
              <h2 className="text-xl font-bold text-slate-800 mb-6">{editingOrderId ? 'Update Order' : 'Create Loading Plan'}</h2>
              <div className="mb-6 p-3 bg-blue-50 text-blue-700 text-sm rounded-lg flex items-center">
                <Calendar className="w-4 h-4 mr-2" />Order for: <span className="font-bold ml-1">{formatDateDisplay(viewDate)}</span>
              </div>
              <form onSubmit={handleSubmitOrder} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <InputGroup label="Client Name"><input required type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.client} onChange={e => setFormData({...formData, client: e.target.value})} /></InputGroup>
                  <InputGroup label="Delivery Location"><input required type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.location} onChange={e => setFormData({...formData, location: e.target.value})} /></InputGroup>
                  <InputGroup label="Vehicle Number"><input required type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.vehicle} onChange={e => setFormData({...formData, vehicle: e.target.value})} /></InputGroup>
                  <InputGroup label="Transporter"><input type="text" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.transporter} onChange={e => setFormData({...formData, transporter: e.target.value})} placeholder="e.g. Demo Logistics" /></InputGroup>
                  <InputGroup label="AAC Size"><select className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none bg-white" value={formData.size} onChange={e => setFormData({...formData, size: e.target.value})}>{SIZES.map(s => <option key={s} value={s}>{s}</option>)}</select></InputGroup>
                  <InputGroup label="CBM"><input required type="number" step="0.01" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.cbm} onChange={e => setFormData({...formData, cbm: e.target.value})} /></InputGroup>
                  <InputGroup label="BJM (Bags)"><input required type="number" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.bjm} onChange={e => setFormData({...formData, bjm: e.target.value})} /></InputGroup>
                  <InputGroup label="Rate (₹)"><input required type="number" className="w-full p-2.5 border border-slate-300 rounded-lg focus:ring-2 focus:ring-blue-500 outline-none" value={formData.rate} onChange={e => setFormData({...formData, rate: e.target.value})} /></InputGroup>
                </div>
                <div className="pt-4 border-t border-slate-100 flex justify-end"><button type="submit" className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2.5 rounded-lg font-bold shadow-sm transition-colors">{editingOrderId ? 'Update Order' : 'Publish Order'}</button></div>
              </form>
            </Card>
          </div>
        )}

        {/* DAILY LOG VIEW */}
        {view === 'daily-log' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white p-3 rounded-xl shadow-sm border border-slate-200">
              {filterMode === 'date' ? (<button onClick={() => handleDateChange(-1)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"><ChevronLeft className="w-5 h-5" /></button>) : (<div className="w-9"></div>)}
              <div className="flex flex-col items-center">
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">{filterMode === 'date' ? 'Daily Loading Plan' : 'Filtered View'}</span>
                {filterMode === 'search' && <span className="text-lg font-bold text-blue-600 flex items-center gap-2 bg-blue-50 px-4 py-1 rounded-full mt-1"><Search className="w-4 h-4" /> Search: "{searchQuery}"</span>}
                {filterMode === 'date' && (
                  <>
                    <span className="text-lg font-bold text-slate-800 flex items-center gap-2"><Calendar className="w-4 h-4 text-blue-500" />{formatDateDisplay(viewDate)}</span>
                    {viewDate === getTodayString() && <span className="text-[10px] text-blue-600 bg-blue-50 px-2 rounded-full font-bold mt-1">TODAY</span>}
                  </>
                )}
                {filterMode === 'active' && <span className="text-lg font-bold text-orange-600 flex items-center gap-2 bg-orange-50 px-4 py-1 rounded-full mt-1"><Truck className="w-4 h-4" /> All Active Loads</span>}
                {filterMode === 'approval' && <span className="text-lg font-bold text-green-600 flex items-center gap-2 bg-green-50 px-4 py-1 rounded-full mt-1"><ShieldCheck className="w-4 h-4" /> Pending Approvals</span>}
                {filterMode === 'backlog' && <span className="text-lg font-bold text-red-600 flex items-center gap-2 bg-red-50 px-4 py-1 rounded-full mt-1"><AlertTriangle className="w-4 h-4" /> Backlog Alert</span>}
                {filterMode === 'pending_invoice' && <span className="text-lg font-bold text-red-600 flex items-center gap-2 bg-red-50 px-4 py-1 rounded-full mt-1"><FileText className="w-4 h-4" /> Billing Required</span>}
              </div>
              {filterMode === 'date' ? (<button onClick={() => handleDateChange(1)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-600 transition-colors"><ChevronRight className="w-5 h-5" /></button>) : (<button onClick={() => setViewAndFilter('daily-log', 'date', getTodayString())} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors" title="Clear Filter"><X className="w-5 h-5" /></button>)}
            </div>

            {displayedOrders.length === 0 ? (
              <div className="text-center py-12 bg-white rounded-xl border border-dashed border-slate-300 text-slate-400">
                {filterMode === 'search' ? 'No orders found.' : 'No records found.'}
              </div>
            ) : (
              <div className="space-y-4">
                {displayedOrders.map((order) => (
                  <Card key={order.id} className="p-5 flex flex-col md:flex-row md:items-start gap-5 hover:shadow-md transition-shadow relative">
                    
                    {/* SALES EDIT/DELETE ACTIONS */}
                    {role === 'sales' && order.orderDate >= getTodayString() && (
                        <div className="absolute top-4 right-4 flex gap-2 z-10">
                           <button 
                             onClick={(e) => { e.stopPropagation(); handleEditOrder(order); }}
                             className="p-1.5 text-slate-400 hover:text-blue-600 hover:bg-blue-50 rounded transition-colors"
                             title="Edit Order"
                           >
                             <Pencil className="w-4 h-4" />
                           </button>
                           <button 
                             onClick={(e) => { e.stopPropagation(); triggerDelete(order.id); }}
                             className="p-1.5 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded transition-colors"
                             title="Delete Order"
                           >
                             <Trash2 className="w-4 h-4" />
                           </button>
                        </div>
                    )}

                    <div className="flex-1 grid grid-cols-2 md:grid-cols-4 gap-4">
                      {filterMode !== 'date' && <div className="absolute -top-5 left-0"><span className="text-[10px] font-bold text-slate-400 uppercase bg-slate-100 px-2 py-0.5 rounded">{formatDateDisplay(order.orderDate)}</span></div>}
                      
                      <div><p className="text-xs text-slate-400 uppercase font-bold">Client</p><p className="font-bold text-slate-800">{order.client}</p><p className="text-xs text-slate-500 truncate">{order.location}</p></div>
                      <div><p className="text-xs text-slate-400 uppercase font-bold">Vehicle</p><p className="font-semibold text-slate-700 bg-slate-100 inline-block px-2 rounded text-sm">{order.vehicle}</p></div>
                      <div><p className="text-xs text-slate-400 uppercase font-bold">Load</p><p className="text-sm text-slate-700"><span className="font-semibold">{order.cbm}</span> CBM</p></div>
                      <div><p className="text-xs text-slate-400 uppercase font-bold">Rate</p><p className="text-sm font-semibold text-slate-700">₹ {order.rate}</p></div>
                    </div>

                    <div className="flex flex-col items-center justify-start pt-2 min-w-[120px] text-center"><StatusBadge status={order.status} /></div>

                    <div className="flex flex-col gap-2 min-w-[160px] border-l pl-4 border-slate-100">
                      {role === 'sales' && (
                        <>
                          {order.status === 'Invoiced' && <button onClick={() => openPreview('invoice', order.invoice || 'Draft', order.id, true)} className="w-full py-2 bg-green-600 text-white text-xs font-bold rounded-lg hover:bg-green-700 flex items-center justify-center"><Eye className="w-3 h-3 mr-1.5"/> Review & Approve</button>}
                          {!['Invoiced'].includes(order.status) && <span className="text-xs text-slate-400 text-center italic">Monitoring...</span>}
                        </>
                      )}
                      {role === 'loading' && (
                        <>
                          {['Awaiting Truck', 'Truck at Site', 'Loading', 'Loading Complete'].includes(order.status) && <select className="w-full py-1.5 px-2 bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded outline-none" value={order.status} onChange={(e) => updateStatus(order.id, e.target.value)}>{LOADING_STATUSES.map(s => <option key={s} value={s}>{s}</option>)}</select>}
                          {order.status === 'Loading Complete' && <span className="text-xs text-red-500 font-medium text-center bg-red-50 py-1 rounded">Waiting for Accounts</span>}
                          {order.status === 'Invoiced' && <span className="text-xs text-indigo-500 font-medium text-center bg-indigo-50 py-1 rounded">Waiting for Sales</span>}
                          {order.status === 'Approved' && (
                            <button onClick={() => setDispatchModalOrderId(order.id)} className="w-full py-2 bg-purple-600 text-white text-xs font-bold rounded-lg hover:bg-purple-700 flex justify-center items-center">
                               <Truck className="w-3 h-3 mr-1.5"/> Dispatch Truck
                            </button>
                          )}
                           {order.status === 'Dispatched' && <span className="text-xs text-green-600 font-bold text-center flex items-center justify-center"><CheckCircle className="w-3 h-3 mr-1" /> Done</span>}
                        </>
                      )}
                      {role === 'accounts' && (
                        <>
                          {order.status === 'Loading Complete' && <button onClick={() => handleFileUpload(order.id, 'invoice', 'Invoiced')} className="w-full py-2 bg-indigo-600 text-white text-xs font-bold rounded-lg hover:bg-indigo-700 flex justify-center items-center"><DollarSign className="w-3 h-3 mr-1"/> Upload Invoice</button>}
                          {order.status !== 'Loading Complete' && <span className="text-xs text-slate-400 text-center italic">Wait for Loading Tm.</span>}
                        </>
                      )}
                       {role === 'management' && (
                        <>
                           {order.status === 'Dispatched' && <span className="text-xs text-green-600 font-bold text-center flex items-center justify-center"><CheckCircle className="w-3 h-3 mr-1" /> Done</span>}
                           {order.status !== 'Dispatched' && <span className="text-xs text-slate-400 text-center italic">{order.status}</span>}
                        </>
                      )}
                    </div>
                  </Card>
                ))}
              </div>
            )}
          </div>
        )}

        {/* SYSTEM LOGS VIEW */}
        {view === 'system-logs' && (
          <div className="space-y-6">
            <div className="flex items-center justify-between bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <div><h2 className="text-lg font-bold text-slate-800 flex items-center gap-2"><ScrollText className="w-5 h-5 text-slate-600"/> System Audit Logs</h2><p className="text-xs text-slate-400">Real-time activity tracking.</p></div>
            </div>
            <div className="bg-white rounded-xl shadow-sm border border-slate-200 overflow-hidden">
              <table className="w-full text-sm text-left">
                <thead className="bg-slate-50 text-slate-500 font-bold uppercase text-xs">
                  <tr><th className="px-4 py-3">Time</th><th className="px-4 py-3">Team</th><th className="px-4 py-3">Action</th><th className="px-4 py-3">Details</th></tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {logs.map(log => (
                    <tr key={log.id} className="hover:bg-slate-50">
                      <td className="px-4 py-2 text-slate-500 whitespace-nowrap text-xs">{formatDateTimeDisplay(log.timestamp)}</td>
                      <td className="px-4 py-2 font-bold text-slate-700 text-xs">{log.team}</td>
                      <td className="px-4 py-2"><span className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider">{log.action}</span></td>
                      <td className="px-4 py-2 text-slate-600">{log.details}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {/* PRODUCTION DASHBOARD VIEW */}
        {view === 'production-dashboard' && (
          <div className="space-y-6">
            <div className="bg-white p-4 rounded-xl shadow-sm border border-slate-200">
              <h2 className="text-lg font-bold text-slate-800 flex items-center gap-2">
                <Factory className="w-5 h-5 text-cyan-600"/> Production Dashboard
              </h2>
              <p className="text-xs text-slate-400">Coming soon: Raw material stock and finished stock reports</p>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

const AppContent = () => {
  const { role, setRole } = useApp();
  if (!role) return <RoleSelection onRoleSelect={(r) => setRole(r)} />;
  return <Dashboard />;
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
